package com.berexia.sas.exception;

public class SasException extends Exception {

    private static final long serialVersionUID = -973189080258779842L;

    public SasException() {
        super();
    }

    public SasException(String message, Throwable cause) {
        super(message, cause);
    }

    public SasException(String message) {
        super(message);
    }

    public SasException(Throwable cause) {
        super(cause);
    }

}
