package com.berexia.study.services;

import com.berexia.study.repositories.ClientRepository;
import com.berexia.study.entities.RefCedentNameEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ClientService {

    @Autowired
    private ClientRepository repository;

    public List<RefCedentNameEntity> getAll()
    {
        List<RefCedentNameEntity> list = new ArrayList<RefCedentNameEntity>();

        for ( RefCedentNameEntity st : repository.findAll())
        {
            list.add(st);
        }
        return list;
    }

    public List<RefCedentNameEntity> getClientsByParentGroup(int parentId )
    {
        List<RefCedentNameEntity> list = new ArrayList<RefCedentNameEntity>();

        for ( RefCedentNameEntity st : repository.findByRcnRpgId(parentId))
        {
            list.add(st);
        }
        return list;
    }
}
