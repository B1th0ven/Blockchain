package com.berexia.study.repositories;

import com.berexia.study.entities.RunEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RunRepository extends CrudRepository<RunEntity, Integer>
{
    List<RunEntity> findByRunDsId(Integer id);

    List<RunEntity> findByRunStId(Integer id);

    RunEntity findByRunId(Integer id);
}
