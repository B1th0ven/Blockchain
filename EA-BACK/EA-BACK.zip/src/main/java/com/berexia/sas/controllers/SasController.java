package com.berexia.sas.controllers;

import com.berexia.sas.exception.SasException;
import com.berexia.sas.services.RunSasService;
import com.berexia.study.entities.RunCalcEntity;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sas.iom.SASIOMDefs.GenericError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.HashMap;

@RestController
public class SasController {

    @Autowired
    RunSasService rr;


    @RequestMapping(value = "/run/start", method = RequestMethod.POST)
    public HashMap<String, String> run(HttpEntity<String> req) throws JsonParseException, JsonMappingException, IOException, SasException, GenericError, Exception {

        HashMap<String, Object> req_map = new ObjectMapper().readValue(req.getBody() , HashMap.class) ;
        String id = (String) req_map.get("run_id");
        String dim = (String) req_map.get("dimensions");

        return rr.run(id,dim);
    }

    @RequestMapping(value = "/run/status/{run_id}", method = RequestMethod.GET)
    public RunCalcEntity runStatus(@PathVariable int run_id) throws IOException  {

        return rr.getRunById(run_id);
    }

}
