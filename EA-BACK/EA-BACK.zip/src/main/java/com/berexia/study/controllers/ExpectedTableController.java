package com.berexia.study.controllers;

import com.berexia.study.entities.RefExpectedTableEntity;
import com.berexia.study.entities.RefLobEntity;
import com.berexia.study.entities.StudyEntity;
import com.berexia.study.services.BusinessService;
import com.berexia.study.services.ExpectedTableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ExpectedTableController {

    @Autowired
    private ExpectedTableService service;

    @RequestMapping("/table")
    public List<RefExpectedTableEntity> getAll()
    {
        return service.getAll();
    }

    @RequestMapping( value="/table", method = RequestMethod.POST)
    public RefExpectedTableEntity save( @RequestBody RefExpectedTableEntity t)
    {
        return service.save(t);
    }


    @RequestMapping( value="/table/latest", method = RequestMethod.POST)
    public int check( @RequestBody RefExpectedTableEntity t)
    {
        return service.getLatestVersion(t);
    }


}
