package com.berexia.study.services;

import com.berexia.study.repositories.DatasetRepository;
import com.berexia.study.entities.DataSetEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DatasetService {

    @Autowired
    private DatasetRepository repository;

    public DataSetEntity postDataset(DataSetEntity ds)
    {
       return repository.save(ds);
    }

    public List<DataSetEntity> getAll()
    {
        List<DataSetEntity> list = new ArrayList<DataSetEntity>();

        for ( DataSetEntity st : repository.findAll())
        {
            list.add(st);
        }
        return list;
    }


    public boolean isStudyDatasetsValid(int id)
    {
        List<DataSetEntity> list = new ArrayList<DataSetEntity>();

        for ( DataSetEntity st : repository.findByDsStId(id))
        {
            if ( st.getDsFuncReport() != null && st.getDsTechReport() != null )
            {
                return true;
            }
        }
        return false;
    }

    public int validStudyDatasetsCount(int id)
    {
        int count = 0;
        List<DataSetEntity> list = new ArrayList<DataSetEntity>();

        for ( DataSetEntity st : repository.findByDsStId(id))
        {
            System.out.println(st.getDsName());
            if ( st.getDsProductFile() != null && st.getDsEventExposureFile() != null &&  st.getDsFuncReport() != null && st.getDsTechReport() != null )
                count++;

            System.out.println(count);
        }

        return count;
    }

    public DataSetEntity getById(int id)
    {
        return this.repository.findOne(id);
    }

    public List<DataSetEntity> getDatasetsByStudyId(int id) {
        return repository.findByDsStId(id);
    }
}
