package com.berexia.study.repositories;

import com.berexia.study.entities.RefLobEntity;
import org.springframework.data.repository.CrudRepository;

public interface BusinessRepository extends CrudRepository<RefLobEntity, Integer>
{

}
