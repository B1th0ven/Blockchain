package com.berexia.ea.spark;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.util.LongAccumulator;

import com.berexia.ea.accumulators.ControlResultAccumulator;
import com.berexia.ea.common.DataPivot;
import com.berexia.ea.entities.AffectedColumn;
import com.berexia.ea.entities.PivotCol;
import com.berexia.ea.entities.ControlResult;
import com.berexia.ea.entities.ControlResults;

public class TechControls implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static ControlResults run(String path, String type) {

		JavaSparkContext sc = Connection.getContext();
		List<PivotCol> pivotCols = DataPivot.getPivotCols();

		JavaRDD<String> data = sc.textFile(path);
		String header = data.first();
		List<String> names = Arrays.asList(header.toLowerCase().trim().split(";", -1));

		// Long threshold = (10*(data.count()-1)*names.size())/100 ;
		Long threshold = (10 * (data.count() - 1)) / 100;

		// System.out.println("___________________________");
		// System.out.println(threshold);
		// System.out.println("___________________________");

		List<String> types = new ArrayList<>();
		List<Boolean> is_mand = new ArrayList<>();
		List<List<String>> possibleVals = new ArrayList<>();
		for (String name : names) {
			boolean found = false;
			for (PivotCol pc : pivotCols) {

				if (name.equals(pc.getName())) {
					found = true;
					types.add(pc.getType());
					if ((type.equalsIgnoreCase("combine")
							& (name.equalsIgnoreCase("exposure_or_event")
									|| name.equalsIgnoreCase("date_of_event_incurred")
									|| name.equalsIgnoreCase("type_of_event"))
							|| pc.getPossiblesValues().contains("empty"))) {
						is_mand.add(false);
					} else {
						is_mand.add(pc.isMandatory());
					}
					possibleVals.add(pc.getPossiblesValues());
					break;
				}
			}
			if (!found) {
				types.add("free Text");
				is_mand.add(false);
				possibleVals.add(null);
			}
		}

		ControlResultAccumulator df_acc = new ControlResultAccumulator(
				new ControlResult("Date format", new ArrayList<>()));
		sc.sc().register(df_acc);

		ControlResultAccumulator nf_acc = new ControlResultAccumulator(
				new ControlResult("Numeric format", new ArrayList<>()));
		sc.sc().register(nf_acc);

		ControlResultAccumulator cf_acc = new ControlResultAccumulator(
				new ControlResult("Code format", new ArrayList<>()));
		sc.sc().register(cf_acc);

		LongAccumulator errorsCount = sc.sc().longAccumulator();

		data.foreach(new VoidFunction<String>() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void call(String line) throws Exception {
				// if(errorsCount.value() <= threshold) {
				if (true) {
					if (!line.equals("") & !line.equalsIgnoreCase(header)) {

						String[] arr = line.toLowerCase().trim().split(";", -1);
						String classification = null;
						if (type.equalsIgnoreCase("split"))
							classification = arr[names.indexOf("exposure_or_event")];
						if (classification == null || classification.equalsIgnoreCase("exposure")
								|| classification.equalsIgnoreCase("event") || classification.equalsIgnoreCase("exposure + event")) {
							List<String> expo_mand_cols = Arrays.asList("exposure_or_event",
									"date_of_begin_current_condition", "date_of_commencement",
									"status_begin_current_condition", "status_end_current_condition",
									"acceleration_risk_type", "main_risk_type","product_id");
							List<String> event_mand_cols = Arrays.asList("exposure_or_event", "date_of_event_incurred",
									"type_of_event", "date_of_commencement", "acceleration_risk_type",
									"main_risk_type","product_id");
							List<String> event_expo_mand_cols = Arrays.asList("exposure_or_event","date_of_commencement",
									"main_risk_type","acceleration_risk_type","status_end_current_condition",
									"status_begin_current_condition","date_of_begin_current_condition","product_id",
									"type_of_event","date_of_event_incurred");

							for (int i = 0; i < arr.length; i++) {
								switch (types.get(i)) {
								case "date":
									if (!arr[i].matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$")) {
										if (arr[i].equals("")) {
											if ("exposure".equalsIgnoreCase(classification)) {
												if (expo_mand_cols.contains(names.get(i))) {
													List<AffectedColumn> affectedColumns = new ArrayList<>();
													affectedColumns.add(new AffectedColumn(names.get(i), 1,
															new ArrayList<>(Arrays.asList(line))));
													df_acc.add(new ControlResult("Date format", affectedColumns));
													errorsCount.add(1);
												}
											} else if ("event".equalsIgnoreCase(classification)) {
												if (event_mand_cols.contains(names.get(i))) {
													List<AffectedColumn> affectedColumns = new ArrayList<>();
													affectedColumns.add(new AffectedColumn(names.get(i), 1,
															new ArrayList<>(Arrays.asList(line))));
													df_acc.add(new ControlResult("Date format", affectedColumns));
													errorsCount.add(1);
												}
											} else if("exposure + event".equalsIgnoreCase(classification)) {
												if (event_expo_mand_cols.contains(names.get(i))) {
													List<AffectedColumn> affectedColumns = new ArrayList<>();
													affectedColumns.add(new AffectedColumn(names.get(i), 1,
															new ArrayList<>(Arrays.asList(line))));
													df_acc.add(new ControlResult("Date format", affectedColumns));
													errorsCount.add(1);
												}
											} else if (is_mand.get(i)) {
												List<AffectedColumn> affectedColumns = new ArrayList<>();
												affectedColumns.add(new AffectedColumn(names.get(i), 1,
														new ArrayList<>(Arrays.asList(line))));
												df_acc.add(new ControlResult("Date format", affectedColumns));
												errorsCount.add(1);
											}
										} else {
											List<AffectedColumn> affectedColumns = new ArrayList<>();
											affectedColumns.add(new AffectedColumn(names.get(i), 1,
													new ArrayList<>(Arrays.asList(line))));
											df_acc.add(new ControlResult("Date format", affectedColumns));
											errorsCount.add(1);
										}
									}
									break;
								case "numeric":
									if (!arr[i].replaceAll("\\,", "\\.").matches("^\\-?\\d+\\.?\\d*$")) {
										if (arr[i].equals("")) {
											if ("exposure".equalsIgnoreCase(classification)) {
												if (expo_mand_cols.contains(names.get(i))) {
													List<AffectedColumn> affectedColumns = new ArrayList<>();
													affectedColumns.add(new AffectedColumn(names.get(i), 1,
															new ArrayList<>(Arrays.asList(line))));
													nf_acc.add(new ControlResult("Numeric format", affectedColumns));
													errorsCount.add(1);
												}
											} else if ("event".equalsIgnoreCase(classification)) {
												if (event_mand_cols.contains(names.get(i))) {
													List<AffectedColumn> affectedColumns = new ArrayList<>();
													affectedColumns.add(new AffectedColumn(names.get(i), 1,
															new ArrayList<>(Arrays.asList(line))));
													nf_acc.add(new ControlResult("Numeric format", affectedColumns));
													errorsCount.add(1);
												}
											} else if("exposure + event".equalsIgnoreCase(classification)) {
												if (event_expo_mand_cols.contains(names.get(i))) {
													List<AffectedColumn> affectedColumns = new ArrayList<>();
													affectedColumns.add(new AffectedColumn(names.get(i), 1,
															new ArrayList<>(Arrays.asList(line))));
													nf_acc.add(new ControlResult("Numeric format", affectedColumns));
													errorsCount.add(1);
												}
											} else if (is_mand.get(i)) {
												List<AffectedColumn> affectedColumns = new ArrayList<>();
												affectedColumns.add(new AffectedColumn(names.get(i), 1,
														new ArrayList<>(Arrays.asList(line))));
												nf_acc.add(new ControlResult("Numeric format", affectedColumns));
												errorsCount.add(1);
											}
										} else {
											List<AffectedColumn> affectedColumns = new ArrayList<>();
											affectedColumns.add(new AffectedColumn(names.get(i), 1,
													new ArrayList<>(Arrays.asList(line))));
											nf_acc.add(new ControlResult("Numeric format", affectedColumns));
											errorsCount.add(1);
										}
									}else if( Double.parseDouble(arr[i].replaceAll("\\,", "\\.")) < 0 & names.get(i).matches(".*age.*") ){
										List<AffectedColumn> affectedColumns = new ArrayList<>();
										affectedColumns.add(new AffectedColumn(names.get(i), 1,
												new ArrayList<>(Arrays.asList(line))));
										nf_acc.add(new ControlResult("Numeric format", affectedColumns));
										errorsCount.add(1);
									}
									break;
									case "age":
										if (!arr[i].matches("\\d+")) {
											if (arr[i].equals("")) {
												if ("exposure".equalsIgnoreCase(classification)) {
													if (expo_mand_cols.contains(names.get(i))) {
														List<AffectedColumn> affectedColumns = new ArrayList<>();
														affectedColumns.add(new AffectedColumn(names.get(i), 1,
																new ArrayList<>(Arrays.asList(line))));
														nf_acc.add(new ControlResult("Numeric format", affectedColumns));
														errorsCount.add(1);
													}
												} else if ("event".equalsIgnoreCase(classification)) {
													if (event_mand_cols.contains(names.get(i))) {
														List<AffectedColumn> affectedColumns = new ArrayList<>();
														affectedColumns.add(new AffectedColumn(names.get(i), 1,
																new ArrayList<>(Arrays.asList(line))));
														nf_acc.add(new ControlResult("Numeric format", affectedColumns));
														errorsCount.add(1);
													}
												} else if("exposure + event".equalsIgnoreCase(classification)) {
													if (event_expo_mand_cols.contains(names.get(i))) {
														List<AffectedColumn> affectedColumns = new ArrayList<>();
														affectedColumns.add(new AffectedColumn(names.get(i), 1,
																new ArrayList<>(Arrays.asList(line))));
														nf_acc.add(new ControlResult("Numeric format", affectedColumns));
														errorsCount.add(1);
													}
												} else if (is_mand.get(i)) {
													List<AffectedColumn> affectedColumns = new ArrayList<>();
													affectedColumns.add(new AffectedColumn(names.get(i), 1,
															new ArrayList<>(Arrays.asList(line))));
													nf_acc.add(new ControlResult("Numeric format", affectedColumns));
													errorsCount.add(1);
												}
											} else {
												List<AffectedColumn> affectedColumns = new ArrayList<>();
												affectedColumns.add(new AffectedColumn(names.get(i), 1,
														new ArrayList<>(Arrays.asList(line))));
												nf_acc.add(new ControlResult("Numeric format", affectedColumns));
												errorsCount.add(1);
											}
										}else if( !(Integer.parseInt(arr[i]) > 0) || !(Integer.parseInt(arr[i]) <= 120) ){
											List<AffectedColumn> affectedColumns = new ArrayList<>();
											affectedColumns.add(new AffectedColumn(names.get(i), 1,
													new ArrayList<>(Arrays.asList(line))));
											nf_acc.add(new ControlResult("Numeric format", affectedColumns));
											errorsCount.add(1);
										}
										break;
								case "code":

									if (!possibleVals.get(i).contains(arr[i]) || arr[i].equalsIgnoreCase("empty")) {
										
										if (arr[i].equals("")) {
											if ("exposure".equalsIgnoreCase(classification)) {
												if (expo_mand_cols.contains(names.get(i))) {
													List<AffectedColumn> affectedColumns = new ArrayList<>();
													affectedColumns.add(new AffectedColumn(names.get(i), 1,
															new ArrayList<>(Arrays.asList(line))));
													cf_acc.add(new ControlResult("Code format", affectedColumns));
													errorsCount.add(1);
												}
											} else if ("event".equalsIgnoreCase(classification)) {
												if (event_mand_cols.contains(names.get(i))) {
													List<AffectedColumn> affectedColumns = new ArrayList<>();
													affectedColumns.add(new AffectedColumn(names.get(i), 1,
															new ArrayList<>(Arrays.asList(line))));
													cf_acc.add(new ControlResult("Code format", affectedColumns));
													errorsCount.add(1);
												}
											}  else if("exposure + event".equalsIgnoreCase(classification)) {
												if (event_expo_mand_cols.contains(names.get(i))) {
													List<AffectedColumn> affectedColumns = new ArrayList<>();
													affectedColumns.add(new AffectedColumn(names.get(i), 1,
															new ArrayList<>(Arrays.asList(line))));
													cf_acc.add(new ControlResult("Code format", affectedColumns));
													errorsCount.add(1);
												}
											} else if (is_mand.get(i)) {
												List<AffectedColumn> affectedColumns = new ArrayList<>();
												affectedColumns.add(new AffectedColumn(names.get(i), 1,
														new ArrayList<>(Arrays.asList(line))));
												cf_acc.add(new ControlResult("Code format", affectedColumns));
												errorsCount.add(1);
											}
										} else {
											List<AffectedColumn> affectedColumns = new ArrayList<>();
											affectedColumns.add(new AffectedColumn(names.get(i), 1,
													new ArrayList<>(Arrays.asList(line))));
											cf_acc.add(new ControlResult("Code format", affectedColumns));
											errorsCount.add(1);
										}
									}
									break;
								default:
									break;
								}
							}
						} else {
							List<AffectedColumn> affectedColumns = new ArrayList<>();
							affectedColumns.add(
									new AffectedColumn("Exposure or Event", 1, new ArrayList<>(Arrays.asList(line))));
							cf_acc.add(new ControlResult("Code format", affectedColumns));
							errorsCount.add(1);
						}

					}
				}
			}
		});

		List<ControlResult> controlResultsList = new ArrayList<>();
		controlResultsList.add(df_acc.value());
		controlResultsList.add(nf_acc.value());
		controlResultsList.add(cf_acc.value());

		return new ControlResults(threshold, errorsCount.value(), controlResultsList, header);
	}

	public static ControlResults runProduct(String path) {

		JavaSparkContext sc = Connection.getContext();
		List<PivotCol> pivotColsProduct = DataPivot.getPivotColsProduct();

		JavaRDD<String> data = sc.textFile(path);
		String header = data.first();
		List<String> names = Arrays.asList(header.toLowerCase().trim().split(";", -1));

		// Long threshold = (10*(data.count()-1)*names.size())/100 ;
		Long threshold = (10 * (data.count() - 1)) / 100;

		// System.out.println("___________________________");
		// System.out.println(threshold);
		// System.out.println("___________________________");

		List<String> types = new ArrayList<>();
		List<Boolean> is_mand = new ArrayList<>();
		List<List<String>> possibleValsProd = new ArrayList<>();
		for (String name : names) {
			boolean found = false;
			for (PivotCol pc : pivotColsProduct) {
				if (name.equals(pc.getName())) {
					found = true;
					types.add(pc.getType());
					is_mand.add(pc.isMandatory());
					possibleValsProd.add(pc.getPossiblesValues());
					break;
				}
			}
			if (!found) {
				types.add("free Text");
				is_mand.add(false);
				possibleValsProd.add(null);
			}
		}

		ControlResultAccumulator df_acc = new ControlResultAccumulator(
				new ControlResult("Date format", new ArrayList<>()));
		sc.sc().register(df_acc);

		ControlResultAccumulator nf_acc = new ControlResultAccumulator(
				new ControlResult("Numeric format", new ArrayList<>()));
		sc.sc().register(nf_acc);

		ControlResultAccumulator cf_acc = new ControlResultAccumulator(
				new ControlResult("Code format", new ArrayList<>()));
		sc.sc().register(cf_acc);

		LongAccumulator errorsCount = sc.sc().longAccumulator();

		data.foreach(new VoidFunction<String>() {

			@Override
			public void call(String line) throws Exception {
				// if(errorsCount.value() <= threshold) {
				if (true) {
					if (!line.equals("") & !line.equalsIgnoreCase(header)) {

						String[] arr = line.toLowerCase().trim().split(";", -1);

						for (int i = 0; i < arr.length; i++) {
							switch (types.get(i)) {
							case "date":
								if (!arr[i].matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$")) {
									if (arr[i].equals("")) {
										if (is_mand.get(i)) {
											List<AffectedColumn> affectedColumns = new ArrayList<>();
											affectedColumns.add(new AffectedColumn(names.get(i), 1,
													new ArrayList<>(Arrays.asList(line))));
											df_acc.add(new ControlResult("Date format", affectedColumns));
											errorsCount.add(1);
										}
									} else {
										List<AffectedColumn> affectedColumns = new ArrayList<>();
										affectedColumns.add(new AffectedColumn(names.get(i), 1,
												new ArrayList<>(Arrays.asList(line))));
										df_acc.add(new ControlResult("Date format", affectedColumns));
										errorsCount.add(1);
									}
								}
								break;
							case "numeric":
								if (!arr[i].matches("^\\-?\\d+\\,?\\d*$")) {
									if (arr[i].equals("")) {
										if (is_mand.get(i)) {
											List<AffectedColumn> affectedColumns = new ArrayList<>();
											affectedColumns.add(new AffectedColumn(names.get(i), 1,
													new ArrayList<>(Arrays.asList(line))));
											nf_acc.add(new ControlResult("Numeric format", affectedColumns));
											errorsCount.add(1);
										}
									} else {
										List<AffectedColumn> affectedColumns = new ArrayList<>();
										affectedColumns.add(new AffectedColumn(names.get(i), 1,
												new ArrayList<>(Arrays.asList(line))));
										nf_acc.add(new ControlResult("Numeric format", affectedColumns));
										errorsCount.add(1);
									}
								}
								break;
								case "age":
									if (!arr[i].matches("\\d+")) {
										if (arr[i].equals("")) {
											if (is_mand.get(i)) {
												List<AffectedColumn> affectedColumns = new ArrayList<>();
												affectedColumns.add(new AffectedColumn(names.get(i), 1,
														new ArrayList<>(Arrays.asList(line))));
												nf_acc.add(new ControlResult("Numeric format", affectedColumns));
												errorsCount.add(1);
											}
										} else {
											List<AffectedColumn> affectedColumns = new ArrayList<>();
											affectedColumns.add(new AffectedColumn(names.get(i), 1,
													new ArrayList<>(Arrays.asList(line))));
											nf_acc.add(new ControlResult("Numeric format", affectedColumns));
											errorsCount.add(1);
										}
									} else if( !(Integer.parseInt(arr[i]) > 0) || !(Integer.parseInt(arr[i]) <= 120))
									{
										List<AffectedColumn> affectedColumns = new ArrayList<>();
										affectedColumns.add(new AffectedColumn(names.get(i), 1,
												new ArrayList<>(Arrays.asList(line))));
										nf_acc.add(new ControlResult("Numeric format", affectedColumns));
										errorsCount.add(1);
									}
									break;
							case "code":
								if (!(possibleValsProd.get(i).contains(arr[i])) || arr[i].equalsIgnoreCase("empty")) {
//									System.out.println("---------->"+possibleValsProd.get(i)+"<-- do not contains --->"+arr[i]+"<--");
									if (arr[i].equals("")) {
										if (is_mand.get(i)) {
											List<AffectedColumn> affectedColumns = new ArrayList<>();
											affectedColumns.add(new AffectedColumn(names.get(i), 1,
													new ArrayList<>(Arrays.asList(line))));
											cf_acc.add(new ControlResult("Code format", affectedColumns));
											errorsCount.add(1);
										}
									} else {
										List<AffectedColumn> affectedColumns = new ArrayList<>();
										affectedColumns.add(new AffectedColumn(names.get(i), 1,
												new ArrayList<>(Arrays.asList(line))));
										cf_acc.add(new ControlResult("Code format", affectedColumns));
										errorsCount.add(1);
									}
								}
								break;
							default:
								break;
							}
						}
					}
				}

			}

		});

		List<ControlResult> controlResultsList = new ArrayList<>();
		controlResultsList.add(df_acc.value());
		controlResultsList.add(nf_acc.value());
		controlResultsList.add(cf_acc.value());

		return new ControlResults(threshold, errorsCount.value(), controlResultsList, header);

	}

}
