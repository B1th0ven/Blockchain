package com.berexia.study.entities;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "REF_PARENT_GROUP", schema = "dbo", catalog = "EXPAN")
public class RefParentGroupEntity {
    private int rpgId;
    private String rpgName;
    private String rpgDescription;

    @Id
    @Column(name = "RPG_ID")
    public int getRpgId() {
        return rpgId;
    }

    public void setRpgId(int rpgId) {
        this.rpgId = rpgId;
    }

    @Basic
    @Column(name = "RPG_NAME")
    public String getRpgName() {
        return rpgName;
    }

    public void setRpgName(String rpgName) {
        this.rpgName = rpgName;
    }

    @Basic
    @Column(name = "RPG_DESCRIPTION")
    public String getRpgDescription() {
        return rpgDescription;
    }

    public void setRpgDescription(String rpgDescription) {
        this.rpgDescription = rpgDescription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RefParentGroupEntity that = (RefParentGroupEntity) o;
        return rpgId == that.rpgId &&
                Objects.equals(rpgName, that.rpgName) &&
                Objects.equals(rpgDescription, that.rpgDescription);
    }

    @Override
    public int hashCode() {

        return Objects.hash(rpgId, rpgName, rpgDescription);
    }
}
