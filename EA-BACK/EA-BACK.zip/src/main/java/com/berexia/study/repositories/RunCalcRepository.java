package com.berexia.study.repositories;

import com.berexia.study.entities.RunCalcEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RunCalcRepository extends CrudRepository<RunCalcEntity, Integer> {

    List<RunCalcEntity> findByRclcRunIdOrderByRclcStartDateDesc(int id);
}
