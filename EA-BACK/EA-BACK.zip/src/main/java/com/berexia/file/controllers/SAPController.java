package com.berexia.file.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;

@Controller()
public class SAPController {

    @RequestMapping(value={"/","/study/**","/home/**"})
    public String SPAPage(){
        return "/index.html";
    }
}
