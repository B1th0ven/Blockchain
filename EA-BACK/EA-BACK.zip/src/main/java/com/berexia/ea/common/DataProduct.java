package com.berexia.ea.common;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.berexia.ea.entities.Product;

public class DataProduct {
	
	private static List<Product> products = null  ;
	
	public static void getProducts(String path_prod) throws IOException {
		if(products == null) {
			products = new ArrayList<>() ;
			String row = null;

			FileReader fr = new FileReader(path_prod); 
			BufferedReader br = new BufferedReader(fr);    
			
			String header = br.readLine() ;
			List<String> names = Arrays.asList(header.toLowerCase().trim().split(";", -1));

			while ((row = br.readLine()) != null) {
	            if(!"".equals(row)) {
	            	String[] row_arr = row.toLowerCase().trim().split(";", -1);
	            	products.add(new Product( row_arr[names.indexOf("product_id")] , row_arr[names.indexOf("age_definition")] )) ;
	            }
			}

		}
	}
	
	public static List<Product> getProd(String path_prod) throws IOException{
		if(products == null) {
			getProducts(path_prod);
		}
		return products;
	}
	

}
