package com.berexia.file.controllers;

import com.berexia.file.entities.file;
import com.berexia.file.services.UploadService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class UploadController {

    @Autowired
    private UploadService uploadService;

    @RequestMapping(value="/upload", method=RequestMethod.POST)
    public file upload(HttpServletRequest request) {
        return uploadService.upload(request,"dataset");

    }

    @RequestMapping(value="/uploadattached", method=RequestMethod.POST)
    public file uploadattached(HttpServletRequest request) {
        return uploadService.upload(request,"attached");

    }

    @RequestMapping(value="/uploadIBNR", method=RequestMethod.POST)
    public file uploadIBNR(HttpServletRequest request) {
        return uploadService.upload(request,"ibnr");

    }

}
