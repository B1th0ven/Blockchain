package com.berexia.file.services;

import com.berexia.file.entities.file;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Service
public class FileService {

    @Value("${custom.upload.path}")
    private String UPLOADED_FOLDER_BASE;


    public List<file> getLoclaFiles() {

        File folder;
        folder = new File(UPLOADED_FOLDER_BASE+"/files");
        System.out.println(folder);
        File[] listOfFiles = folder.listFiles();

        ArrayList<file> listFiles = new ArrayList<>();

        if ( listOfFiles != null )
        {
            for (int i = 0; i < listOfFiles.length; i++) {
                if (listOfFiles[i].isFile())
                {
                    String type = FilenameUtils.getExtension(listOfFiles[i].getName());
                    //System.out.println(type);
                    if ( type.equals("csv") || type.equals("xlsx") || type.equals("xls") )
                    {
                        listFiles.add(
                                new file(
                                        listOfFiles[i].getName(),
                                        listOfFiles[i].getPath(),
                                        (int) listOfFiles[i].length(),
                                        type
                                )
                        );
                        System.out.println("File " + listOfFiles[i].getName());
                    }

                }
            }
        }

        return listFiles;
    }

}
