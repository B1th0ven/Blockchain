package com.berexia.study.repositories;

import com.berexia.study.entities.RefRequesterEntity;
import org.springframework.data.repository.CrudRepository;

public interface ClientTypeRepository extends CrudRepository<RefRequesterEntity, Integer>
{

}
