package com.berexia.study.repositories;

import com.berexia.study.entities.DataSetEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface DatasetRepository extends CrudRepository<DataSetEntity, Integer>
{
    List<DataSetEntity> findByDsStId(int id);
}
