package com.berexia.study.controllers;

import com.berexia.study.entities.RefTreatyEntity;
import com.berexia.study.services.TreatyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TreatyController {

    @Autowired
    private TreatyService treatyService;

    @RequestMapping("/treaties")
    public List<RefTreatyEntity> getTreaties()
    {
        return treatyService.getAllTreaties();

    }

    @RequestMapping("/treaties/clients/{id}")
    public List<RefTreatyEntity> getTreatiesByClients(@PathVariable("id") int clientId)
    {
        return treatyService.getAllTreatiesByClientId(clientId);

    }
}
