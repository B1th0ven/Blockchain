package com.berexia.study.services;

import com.berexia.study.repositories.CountryRepository;
import com.berexia.study.entities.RefCountryEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CountryService {

    @Autowired
    private CountryRepository repository;

    public List<RefCountryEntity> getAll()
    {
        List<RefCountryEntity> list = new ArrayList<RefCountryEntity>();

        for ( RefCountryEntity st : repository.findAll())
        {
            list.add(st);
        }
        return list;
    }
}
