package com.berexia.study.controllers;

import com.berexia.study.entities.RefCalculationEngineTypeEntity;
import com.berexia.study.services.CalculationEngineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class CalculationEngineController {

    @Autowired
    private CalculationEngineService service;

    @RequestMapping("/engines")
    public List<RefCalculationEngineTypeEntity> getClients()
    {
        return service.getAll();
    }
}
