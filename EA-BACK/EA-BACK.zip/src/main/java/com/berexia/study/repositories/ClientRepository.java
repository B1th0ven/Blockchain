package com.berexia.study.repositories;

import com.berexia.study.entities.RefCedentNameEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ClientRepository extends CrudRepository<RefCedentNameEntity, Integer>
{

    List<RefCedentNameEntity> findByRcnRpgId(int parentId);
}
