package com.berexia.study.controllers;

import com.berexia.study.entities.RefCedentNameEntity;
import com.berexia.study.services.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ClientController {

    @Autowired
    private ClientService clientService;

    @RequestMapping("/clients")
    public List<RefCedentNameEntity> getClients()
    {
        return clientService.getAll();
    }

    @RequestMapping("/clients/groups/{id}")
    public List<RefCedentNameEntity> getClientsByParentGroup(@PathVariable("id") int parentId)
    {
        return clientService.getClientsByParentGroup(parentId);
    }
}
