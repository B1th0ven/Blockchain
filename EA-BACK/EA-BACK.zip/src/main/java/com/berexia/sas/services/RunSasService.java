package com.berexia.sas.services;

import com.berexia.file.entities.file;
import com.berexia.sas.entities.SasConnectionWrapper;
import com.berexia.sas.exception.SasException;
import com.berexia.study.entities.DataSetEntity;
import com.berexia.study.entities.EaFilesEntity;
import com.berexia.study.entities.RunCalcEntity;
import com.berexia.study.entities.RunEntity;
import com.berexia.study.repositories.RunCalcRepository;
import com.berexia.study.services.DatasetService;
import com.berexia.study.services.RunService;
import com.sas.iom.SAS.ILanguageService;
import com.sas.iom.SAS.ILanguageServicePackage.CarriageControlSeqHolder;
import com.sas.iom.SAS.ILanguageServicePackage.LineTypeSeqHolder;
import com.sas.iom.SAS.IWorkspace;
import com.sas.iom.SASIOMDefs.GenericError;
import com.sas.iom.SASIOMDefs.StringSeqHolder;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.locks.ReentrantLock;


@Service
public class RunSasService {

    private static ReentrantLock lock = new ReentrantLock();

    @Autowired
    SasConnection CCC;

    @Autowired
    RunService rs;

    @Autowired
    DatasetService ds;

    @Value("${sas-run-repo}")
    private String run_repo;

    @Value("${sas-user}")
    private String sas_username;

    @Value("${sas-pass}")
    private String sas_password;

    @Value("${sas-domain}")
    private String sas_domain;

    public RunSasService(){}

    public HashMap<String,String> run(String id, String dim ) throws Exception {

        if(id == null || !id.matches("^\\d+$"))
            throw new Exception("Failed");
        if(Files.exists(Paths.get(run_repo+id)))
            return new HashMap<String, String>(){{put("status","started");}};

        RunEntity run = rs.getByRunId(Integer.parseInt(id));
        DataSetEntity dataset =  ds.getById(run.getRunDsId());
        EaFilesEntity dsEventExposureFile = dataset.getDsEventExposureFile();
        String path_policy = dsEventExposureFile.getEafLink();
        EaFilesEntity dsProductFile = dataset.getDsProductFile();
        String path_product = dsProductFile.getEafLink();
        String type =  dataset.getDsDataStructureType().trim().toUpperCase();
        String path_udf = run.getRunIbnrAllocation();
        String path_amount = run.getRunIbnrAmount();
        String path_allocation = run.getRunIbnrAllocation();

        //NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("domain", "user", "password");

       // String user = "eu\\SVC_SasOnJava:TyHz6ZNUpeEQn20nawgZ";
        System.out.println(sas_domain+" "+sas_username+" "+sas_password);
        NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(sas_domain,sas_username,sas_password);



         new Thread(() -> {
             //Generate the sas cmd from data/run.sas to launch the SAS program
             String res;
             CodeBuilder cb = new CodeBuilder();
             if(dim != null)
                 res = cb.getCode(id,dim,type);
             else
                 res = cb.getCode(id,"",type);

             //create the run folder on the SAS server
            // new File(run_repo+id).mkdirs();
             //new File(run_repo+id+"\\output").mkdirs();
             //new File(run_repo+id+"\\input").mkdirs();
             String path_run = "smb:"+run_repo.replaceAll("\\\\","/")+id;
             String path_input = "smb:"+run_repo.replaceAll("\\\\","/")+id+"/input";
             String path_output = "smb:"+run_repo.replaceAll("\\\\","/")+id+"/output";
             SmbFile sFile = null;
             try {
                 sFile = new SmbFile(path_run, auth);
                 sFile.mkdirs();
                 sFile = new SmbFile(path_input, auth);
                 sFile.mkdirs();
                 sFile = new SmbFile(path_output, auth);
                 sFile.mkdirs();

             } catch (Exception e) {
                 e.printStackTrace();
             }

                     //Copy the input files to the run folder
                     //Files.copy(Paths.get("C:\\Users\\u006993\\Desktop\\EAback\\files\\combined.csv"), Paths.get(run_repo+id+"\\input\\policy.csv"));
                     //Files.copy(Paths.get("C:\\Users\\u006993\\Desktop\\EAback\\files\\product.csv"), Paths.get(run_repo+id+"\\input\\product.csv"));
                     copy(id,auth,path_policy,"policy.csv");
                     copy(id,auth,path_product,"product.csv");


                     if(path_udf != null && !path_udf.isEmpty())
                         copy(id,auth,path_udf,"ibnr_udf");
                     if(path_allocation != null && !path_allocation.isEmpty())
                         copy(id,auth,path_allocation,"ibrn_allocation");
                     if(path_amount != null && !path_amount.isEmpty())
                         copy(id,auth,path_amount,"ibnr_amount");


                 lock.lock();
             //Submit the cmd to the SAS server
              SasConnectionWrapper con = null;
              try {

                  con = CCC.getConnectionWrapperByWorkspaceFactory();
                    IWorkspace iw = con.getIWorkspace();
                    ILanguageService il = iw.LanguageService();
                    il.Submit(res);
                 /* CarriageControlSeqHolder logCCHldr = new CarriageControlSeqHolder();
                  LineTypeSeqHolder logLTHldr = new LineTypeSeqHolder();
                  StringSeqHolder logHldr = new StringSeqHolder();
                  il.FlushLogLines(Integer.MAX_VALUE, logCCHldr, logLTHldr, logHldr);
                  String[] logLines = logHldr.value;*/
                 // System.out.println(Arrays.toString(logLines));
                  System.out.println("run finished "+id);

              } catch (SasException e) {
                  System.out.println("run failed "+id);

                  e.printStackTrace();
                } catch (GenericError genericError) {
                  System.out.println("run failed "+id);

                  genericError.printStackTrace();
                } finally {
                  lock.unlock();
              }
            }).start();

        return new HashMap<String, String>(){{put("status","started");}};

    }

    public RunCalcEntity getRunById (int id) {
        return rs.getRunCalcById(id);
    }

    private void copy(String id,NtlmPasswordAuthentication auth,String path,String filename) {

        Path source = Paths.get(path);
        SmbFile newFile = null;
        try {
            newFile = new SmbFile("smb:"+run_repo.replaceAll("\\\\","/")+id+"/input/"+filename, auth);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        try (OutputStream out = newFile.getOutputStream())
        {
            Files.copy(source, out);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
