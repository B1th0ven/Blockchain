package com.berexia.study.repositories;

import com.berexia.study.entities.RefCountryEntity;
import org.springframework.data.repository.CrudRepository;

public interface CountryRepository extends CrudRepository<RefCountryEntity, Integer>
{

}
