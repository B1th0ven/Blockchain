package com.berexia.sas.services;


import com.berexia.sas.entities.SasConnectionWrapper;
import com.berexia.sas.exception.SasException;
import com.sas.iom.SAS.IWorkspace;
import com.sas.iom.WorkspaceConnector;
import com.sas.iom.WorkspaceFactory;
import com.sas.iom.WorkspaceFactoryException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class SasConnection {

    @Value("${sas-server-name}")
    private String serverName;
    @Value("${sas-port}")
    private String serverPort;
    @Value("${sas-user}")
    private  String serverUser;
    @Value("${sas-pass}")
    private String serverPass;
    @Value("${sas-domain}")
    private String sas_domain;

    public SasConnection(){}

    public SasConnectionWrapper getConnectionWrapperByWorkspaceFactory() throws SasException {
        try {
            final long td = System.currentTimeMillis();
            final Properties iomServerProperties = new Properties();
            iomServerProperties.put("host", serverName);
            iomServerProperties.put("port", serverPort);
            iomServerProperties.put("userName", sas_domain+"\\"+serverUser);
            iomServerProperties.put("password", serverPass);

//			Properties[] serverList = { iomServerProperties };

            // Connect to the Workspace
          //  LogTools.debug(LOG, "Get workspace..");
            final WorkspaceFactory wFactory = new WorkspaceFactory();
            final IWorkspace iWorkspace = wFactory.createWorkspaceByServer(iomServerProperties);
            if (iWorkspace == null) {
               // LogTools.error(LOG, "Error Connecting...");
                return null;
            }
          //  LogTools.debug(LOG, "...done in "+(System.currentTimeMillis()-td));

            final SasConnectionWrapper cw = new SasConnectionWrapper(serverName, iWorkspace);
            cw.setWorkspaceFactory(wFactory);
            return cw;
        } catch (WorkspaceFactoryException e) {
            throw new SasException(e);
        }
    }

}
