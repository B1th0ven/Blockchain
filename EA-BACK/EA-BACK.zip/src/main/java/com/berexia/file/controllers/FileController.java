package com.berexia.file.controllers;

import com.berexia.file.entities.file;
import com.berexia.file.services.FileService;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.util.List;

@RestController
public class FileController {
    @Value("${custom.upload.path}")
    private String UPLOADED_FOLDER_BASE;

    @Autowired
    private FileService fileService;

    @RequestMapping("/explorer")
    public List<file> FileService()
    {
        return fileService.getLoclaFiles();
    }


    @RequestMapping("/clean")
    public void clean()
    {
        File dir = new File(UPLOADED_FOLDER_BASE+"/files");

        for(File file: dir.listFiles())
            if (!file.isDirectory())
                file.delete();
    }
}
