package com.berexia.ea.entities;

public class Product {

	private String id;
	private String age_def;

	// ..etc
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAge_def() {
		return age_def;
	}

	public void setAge_def(String age_def) {
		this.age_def = age_def;
	}

	public Product(String id, String age_def) {
		super();
		this.id = id;
		this.age_def = age_def;
	}

}
