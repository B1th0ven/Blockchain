package com.berexia.study.controllers;

import com.berexia.study.entities.RefLobEntity;
import com.berexia.study.entities.RunEntity;
import com.berexia.study.services.BusinessService;
import com.berexia.study.services.RunService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController()
@RequestMapping("/run")
public class RunController {

    @Autowired
    private RunService service;

    @RequestMapping(value="", method = RequestMethod.GET)
    public List<RunEntity> getRuns()
    {
        return service.getAll();

    }

    @RequestMapping(value="/dataset", method = RequestMethod.GET)
    public List<RunEntity> getRunsByDataset(@RequestParam("id") int id)
    {
        return service.getByDatasetId(id);
    }

    @RequestMapping(value="/study", method = RequestMethod.GET)
    public List<RunEntity> getRunsByStudy(@RequestParam("id") int id)
    {
        return service.getByStudyId(id);
    }

    @RequestMapping(value="", method = RequestMethod.POST)
    public RunEntity saveRun(@RequestBody  RunEntity run)
    {
        return service.save(run);
    }

    @RequestMapping(value="", method = RequestMethod.DELETE)
    public void delete(@RequestParam("id") int id)
    {
        service.delete(id);
    }
}
