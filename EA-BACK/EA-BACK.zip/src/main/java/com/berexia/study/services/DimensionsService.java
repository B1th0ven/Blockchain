package com.berexia.study.services;

import com.berexia.ea.common.DimensionPivot;
import com.berexia.study.entities.RefLobEntity;
import com.berexia.study.repositories.BusinessRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DimensionsService {

    public List<String> getAll()
    {
        return DimensionPivot.getDimensionCols();
    }
}
