package com.berexia.study.controllers;

import com.berexia.study.entities.DataSetEntity;
import com.berexia.study.services.DatasetService;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class DatasetController {

    @Autowired
    private DatasetService service;

    @RequestMapping("/datasets")
    public List<DataSetEntity> getDatasets()
    {
        return service.getAll();
    }

    @RequestMapping("/datasets/study/{id}")
    public List<DataSetEntity> getDatasetsByStudyId(@PathVariable("id") int id)
    {
        System.out.println("--------------------------------------");
        return service.getDatasetsByStudyId(id);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/datasets")
    public DataSetEntity saveDataset(@RequestBody() DataSetEntity ds)
    {
        return service.postDataset(ds);
    }

    @RequestMapping(value = "/datasets/run/study/{id}")
    public ObjectNode isStudyDatasetsValid(@PathVariable("id") int id) throws JSONException {
        int count = service.validStudyDatasetsCount(id);
        boolean valid = count>0;

        String res = "{'valid':'"+valid+"'}";
        ObjectNode node = JsonNodeFactory.instance.objectNode(); // initializing
        node.put("valid", valid); // building
        node.put("count", count); // building
        return node;
    }

}
