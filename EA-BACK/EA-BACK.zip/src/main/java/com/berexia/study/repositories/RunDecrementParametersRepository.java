package com.berexia.study.repositories;

import com.berexia.study.entities.DecrementParametersEntity;
import com.berexia.study.entities.RefLobEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RunDecrementParametersRepository extends CrudRepository<DecrementParametersEntity, Integer>
{
    //List<DecrementParametersEntity> deleteByDpRunId(int id);
}
