package com.berexia.study.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "DECREMENT_EXPECTED_TABLE", schema = "dbo", catalog = "EXPAN")
public class DecrementExpectedTableEntity {
    private int decetId;
//    private int retDpId;
//    private Integer retBase;
//    private Integer retTrend;
//    private Integer retAdjustment;
    private DecrementParametersEntity decrementParametersByRetBase;
    private RefExpectedTableEntity refExpectedTableByRetBase;
    private RefExpectedTableEntity refExpectedTableByRetTrend;
    private RefExpectedTableEntity refExpectedTableByRetAdjustment;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DECET_ID")
    public int getDecetId() {
        return decetId;
    }

    public void setDecetId(int decetId) {
        this.decetId = decetId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DecrementExpectedTableEntity that = (DecrementExpectedTableEntity) o;
        return decetId == that.decetId;
    }

    @Override
    public int hashCode() {

        return Objects.hash(decetId);
    }
//
//    @Basic
//    @Column(name = "RET_BASE")
//    public Integer getRetBase() {
//        return retBase;
//    }
//
//    public void setRetBase(Integer retBase) {
//        this.retBase = retBase;
//    }
//
//    @Basic
//    @Column(name = "RET_TREND")
//    public Integer getRetTrend() {
//        return retTrend;
//    }
//
//    public void setRetTrend(Integer retTrend) {
//        this.retTrend = retTrend;
//    }
//
//    @Basic
//    @Column(name = "RET_ADJUSTMENT")
//    public Integer getRetAdjustment() {
//        return retAdjustment;
//    }
//
//    public void setRetAdjustment(Integer retAdjustment) {
//        this.retAdjustment = retAdjustment;
//    }
//
//    @Basic
//    @Column(name = "RET_DP_ID")
//    public int getRetDpId() {
//        return retDpId;
//    }
//
//    public void setRetDpId(int retDpId) {
//        this.retDpId = retDpId;
//    }

    @ManyToOne()
    @JoinColumn(name = "RET_DP_ID", referencedColumnName = "DP_ID")
    @JsonBackReference
    public DecrementParametersEntity getDecrementParametersByRetBase() {
        return decrementParametersByRetBase;
    }

    public void setDecrementParametersByRetBase(DecrementParametersEntity decrementParametersByRetBase) {
        this.decrementParametersByRetBase = decrementParametersByRetBase;
    }

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "RET_BASE", referencedColumnName = "RET_ID")
    public RefExpectedTableEntity getRefExpectedTableByRetBase() {
        return refExpectedTableByRetBase;
    }

    public void setRefExpectedTableByRetBase(RefExpectedTableEntity refExpectedTableByRetBase) {
        this.refExpectedTableByRetBase = refExpectedTableByRetBase;
    }

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "RET_TREND", referencedColumnName = "RET_ID")
    public RefExpectedTableEntity getRefExpectedTableByRetTrend() {
        return refExpectedTableByRetTrend;
    }

    public void setRefExpectedTableByRetTrend(RefExpectedTableEntity refExpectedTableByRetTrend) {
        this.refExpectedTableByRetTrend = refExpectedTableByRetTrend;
    }

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "RET_ADJUSTMENT", referencedColumnName = "RET_ID")
    public RefExpectedTableEntity getRefExpectedTableByRetAdjustment() {
        return refExpectedTableByRetAdjustment;
    }

    public void setRefExpectedTableByRetAdjustment(RefExpectedTableEntity refExpectedTableByRetAdjustment ) {
        this.refExpectedTableByRetAdjustment = refExpectedTableByRetAdjustment;
    }
}
