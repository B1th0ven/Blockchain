package com.berexia.ea.ibrn;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class IbnrService {

    public List<String> compoloryCheck(String filePath, String type) throws Exception{

        List<String> headerColumns = loadFileHeader(filePath);
        List<IbnrPivotEntity> pivots = IbnrPivotLoader.getByName(type);

        return compUnicityColumnsCheck(headerColumns, pivots);
    }

    public List<String> techControls(String filePath, String type) throws Exception {
        Stream<String> lines = readFileContent(filePath);
        List<String>   header = loadFileHeader(filePath);
        List<IbnrPivotEntity> pivots = IbnrPivotLoader.getByName(type);

        List<String> errorReport = new ArrayList<String>();

        List<IbnrPivotEntity> headerPivots = new ArrayList<IbnrPivotEntity>();
        AtomicInteger lineCounter = new AtomicInteger();
        lines.forEach((String line) ->{
            lineCounter.getAndIncrement();
            List<String> values = Arrays.asList(line.split(";", -1));
            int i = 0;
            for (String head: header )
            {
                if (header.size()!=values.size())
                {
                    errorReport.add("Header size does not match line values size");
                    continue;
                }
                Optional<IbnrPivotEntity> pivot = pivots.stream().filter(p -> p.getName().toLowerCase().equals(head.toLowerCase())).findFirst();

                //Check if field is empty
                if (values.get(i).isEmpty())
                {
                    errorReport.add("Value of " + head + " is empty in line " + lineCounter );
                }
                else if (pivot.isPresent())
                {
                    //REGEX VALUE MATCHING
                    if (!pivot.get().getRegex().isEmpty())
                    {
                        if (values.get(i).matches(pivot.get().getRegex()))
                        {
                            System.out.println(values.get(i) + " matches " + pivot.get().getRegex());
                        }else
                        {
                            errorReport.add(values.get(i) + " does not match " + pivot.get().getRegex());
                        }
                    }
                    else
                    {
                        if ( pivot.get().getType().toLowerCase().equals("numeric+") )
                        {
                            //SEE IF NUMBER TYPE FIELDS ARE POSITIVE
                            try
                            {
                                float numericValue = Float.parseFloat(String.join(".",values.get(i).split(",")) );
                                if ( numericValue < 0 )
                                {
                                    errorReport.add(values.get(i) +" is not a positive value in line " + lineCounter);
                                }
                            }catch ( Exception e)
                            {
                                errorReport.add(values.get(i) +" is not a numeric value in line " + lineCounter);
                            }
                        }else if ( pivot.get().getType().toLowerCase().equals("numeric") ) {
                            //SEE IF NUMBER TYPE FIELDS ARE POSITIVE
                            try {
                                float numericValue = Float.parseFloat(String.join(".", values.get(i).split(",")));
                            } catch (Exception e) {
                                errorReport.add(values.get(i) + " is not a numeric value in line " + lineCounter);
                            }
                        }
                    }
                }else
                {
                    System.out.println(values.get(i) + " does not have a pivot. Head = "+ head);
                }

                i++;
            }
        });

        return errorReport;
    }

    private List<String> loadFileHeader(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        Stream<String> lines = Files.lines(path);
        return Arrays.asList(lines.findFirst().get().split(";"));
    }

    private Stream<String> readFileContent(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        Stream<String> lines = Files.lines(path);
        return lines.skip(1);
    }

    private List<String> possibleValuesCheck()
    {

        return null;
    }

    private List<String> compUnicityColumnsCheck(List<String> headerColumns, List<IbnrPivotEntity> pivots) {
        //Unicity Check
        int  unicity = 0;
        List<String> errorReport = new ArrayList<String>();
        List<IbnrPivotEntity> uniqueHeaders = new ArrayList<IbnrPivotEntity>();
        List<IbnrPivotEntity> requiredHeaders = new ArrayList<IbnrPivotEntity>();

        requiredHeaders = pivots.stream().filter(p->p.isRequired()&&!p.isUnique()).collect(Collectors.toList());
        uniqueHeaders = pivots.stream().filter(p->p.isUnique()&&p.getUnicityId()>0).collect(Collectors.toList());

        for ( IbnrPivotEntity pivot : requiredHeaders )
        {
            int ind = headerColumns.indexOf(pivot.getName());
            if ( ind < 0 )
                errorReport.add(pivot.getName()+" is required but missing.");
        }

        Set<Integer> unicityIds = new HashSet<Integer>();

        for ( IbnrPivotEntity pivot : uniqueHeaders )
        {
            unicityIds.add(pivot.getUnicityId());
        }

        for ( Integer id : unicityIds )
        {
            List<String> unicityCounter = new ArrayList<String>();
            List<IbnrPivotEntity> exclusivePivots = uniqueHeaders.stream().filter(p->p.getUnicityId()==id).collect(Collectors.toList());
            for ( IbnrPivotEntity exlPivot : exclusivePivots )
            {
                if (headerColumns.contains(exlPivot.getName()))
                    unicityCounter.add(exlPivot.getName());
            }

            if ( unicityCounter.size() <= 0 )
            {
                errorReport.add("Unique Mandatory Columns of id "+id+" missing");
            }else if (unicityCounter.size()>1)
            {
                errorReport.add("More than one Unique Mandatory Columns of id "+id+" found " + unicityCounter);
            }
        }

        return errorReport;
    }

    private boolean isColumnUnique()
    {
        return false;
    }
}
