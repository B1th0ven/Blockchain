package com.berexia.study.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "RUN", schema = "dbo", catalog = "EXPAN")
public class RunEntity {
    private int runId;
    private Integer runRimId;
    private String runCode;
    private String runDescription;
    private String runStatus;
    private Date runCreationDate;
    private Boolean runMasterRun;
    private Integer runCreatedBy;
    private String runExposureMetric;
    private String runAttainedAgeDef;
    private Boolean runAutRiskAmountChangeSplit;
    private Boolean runByCountAnalysis;
    private Boolean runByAmountAnalysis;
    private String runByAmountAnalysisBasis;
    private Boolean runByAmountCapped;
    private Boolean runLossRatioAnalysis;
    private String runLossRatioAnalysisBasis;
    private BigDecimal runCappedAmount;
    private String runIbnrManuelUdf;
    private String runIbnrAmount;
    private String runIbnrAllocation;
    private String runFilterJsonUrl;
    private String runIbnrMethod;
    private Integer runDsId;
    private Integer runStId;
    private Collection<DecrementParametersEntity> decrementParametersByRunId;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RUN_ID")
    public int getRunId() {
        return runId;
    }

    public void setRunId(int runId) {
        this.runId = runId;
    }

    @Basic
    @Column(name = "RUN_RIM_ID")
    public Integer getRunRimId() {
        return runRimId;
    }

    public void setRunRimId(Integer runRimId) {
        this.runRimId = runRimId;
    }

    @Basic
    @Column(name = "RUN_CODE")
    public String getRunCode() {
        return runCode;
    }

    public void setRunCode(String runCode) {
        this.runCode = runCode;
    }

    @Basic
    @Column(name = "RUN_DESCRIPTION")
    public String getRunDescription() {
        return runDescription;
    }

    public void setRunDescription(String runDescription) {
        this.runDescription = runDescription;
    }

    @Basic
    @Column(name = "RUN_STATUS")
    public String getRunStatus() {
        return runStatus;
    }

    public void setRunStatus(String runStatus) {
        this.runStatus = runStatus;
    }

    @Basic
    @Column(name = "RUN_CREATION_DATE")
    public Date getRunCreationDate() {
        return runCreationDate;
    }

    public void setRunCreationDate(Date runCreationDate) {
        this.runCreationDate = runCreationDate;
    }

    @Basic
    @Column(name = "RUN_MASTER_RUN")
    public Boolean getRunMasterRun() {
        return runMasterRun;
    }

    public void setRunMasterRun(Boolean runMasterRun) {
        this.runMasterRun = runMasterRun;
    }

    @Basic
    @Column(name = "RUN_CREATED_BY")
    public Integer getRunCreatedBy() {
        return runCreatedBy;
    }

    public void setRunCreatedBy(Integer runCreatedBy) {
        this.runCreatedBy = runCreatedBy;
    }

    @Basic
    @Column(name = "RUN_EXPOSURE_METRIC")
    public String getRunExposureMetric() {
        return runExposureMetric;
    }

    public void setRunExposureMetric(String runExposureMetric) {
        this.runExposureMetric = runExposureMetric;
    }

    @Basic
    @Column(name = "RUN_ATTAINED_AGE_DEF")
    public String getRunAttainedAgeDef() {
        return runAttainedAgeDef;
    }

    public void setRunAttainedAgeDef(String runAttainedAgeDef) {
        this.runAttainedAgeDef = runAttainedAgeDef;
    }

    @Basic
    @Column(name = "RUN_AUT_RISK_AMOUNT_CHANGE_SPLIT")
    public Boolean getRunAutRiskAmountChangeSplit() {
        return runAutRiskAmountChangeSplit;
    }

    public void setRunAutRiskAmountChangeSplit(Boolean runAutRiskAmountChangeSplit) {
        this.runAutRiskAmountChangeSplit = runAutRiskAmountChangeSplit;
    }

    @Basic
    @Column(name = "RUN_BY_COUNT_ANALYSIS")
    public Boolean getRunByCountAnalysis() {
        return runByCountAnalysis;
    }

    public void setRunByCountAnalysis(Boolean runByCountAnalysis) {
        this.runByCountAnalysis = runByCountAnalysis;
    }

    @Basic
    @Column(name = "RUN_BY_AMOUNT_ANALYSIS")
    public Boolean getRunByAmountAnalysis() {
        return runByAmountAnalysis;
    }

    public void setRunByAmountAnalysis(Boolean runByAmountAnalysis) {
        this.runByAmountAnalysis = runByAmountAnalysis;
    }

    @Basic
    @Column(name = "RUN_BY_AMOUNT_ANALYSIS_BASIS")
    public String getRunByAmountAnalysisBasis() {
        return runByAmountAnalysisBasis;
    }

    public void setRunByAmountAnalysisBasis(String runByAmountAnalysisBasis) {
        this.runByAmountAnalysisBasis = runByAmountAnalysisBasis;
    }

    @Basic
    @Column(name = "RUN_BY_AMOUNT_CAPPED")
    public Boolean getRunByAmountCapped() {
        return runByAmountCapped;
    }

    public void setRunByAmountCapped(Boolean runByAmountCapped) {
        this.runByAmountCapped = runByAmountCapped;
    }

    @Basic
    @Column(name = "RUN_LOSS_RATIO_ANALYSIS")
    public Boolean getRunLossRatioAnalysis() {
        return runLossRatioAnalysis;
    }

    public void setRunLossRatioAnalysis(Boolean runLossRatioAnalysis) {
        this.runLossRatioAnalysis = runLossRatioAnalysis;
    }

    @Basic
    @Column(name = "RUN_LOSS_RATIO_ANALYSIS_BASIS")
    public String getRunLossRatioAnalysisBasis() {
        return runLossRatioAnalysisBasis;
    }

    public void setRunLossRatioAnalysisBasis(String runLossRatioAnalysisBasis) {
        this.runLossRatioAnalysisBasis = runLossRatioAnalysisBasis;
    }

    @Basic
    @Column(name = "RUN_CAPPED_AMOUNT")
    public BigDecimal getRunCappedAmount() {
        return runCappedAmount;
    }

    public void setRunCappedAmount(BigDecimal runCappedAmount) {
        this.runCappedAmount = runCappedAmount;
    }

    @Basic
    @Column(name = "RUN_IBNR_MANUEL_UDF")
    public String getRunIbnrManuelUdf() {
        return runIbnrManuelUdf;
    }

    public void setRunIbnrManuelUdf(String runIbnrManuelUdf) {
        this.runIbnrManuelUdf = runIbnrManuelUdf;
    }

    @Basic
    @Column(name = "RUN_IBNR_AMOUNT")
    public String getRunIbnrAmount() {
        return runIbnrAmount;
    }

    public void setRunIbnrAmount(String runIbnrAmount) {
        this.runIbnrAmount = runIbnrAmount;
    }

    @Basic
    @Column(name = "RUN_IBNR_ALLOCATION")
    public String getRunIbnrAllocation() {
        return runIbnrAllocation;
    }

    public void setRunIbnrAllocation(String runIbnrAllocation) {
        this.runIbnrAllocation = runIbnrAllocation;
    }

    @Basic
    @Column(name = "RUN_FILTER_JSON_URL")
    public String getRunFilterJsonUrl() {
        return runFilterJsonUrl;
    }

    @Basic
    @Column(name = "RUN_IBNR_METHOD")
    public String getRunIbnrMethod() {
        return runIbnrMethod;
    }

    public void setRunIbnrMethod(String runIbnrMethod) {
        this.runIbnrMethod = runIbnrMethod;
    }

    public void setRunFilterJsonUrl(String runFilterJsonUrl) {
        this.runFilterJsonUrl = runFilterJsonUrl;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RunEntity runEntity = (RunEntity) o;
        return runId == runEntity.runId &&
                Objects.equals(runRimId, runEntity.runRimId) &&
                Objects.equals(runCode, runEntity.runCode) &&
                Objects.equals(runDescription, runEntity.runDescription) &&
                Objects.equals(runStatus, runEntity.runStatus) &&
                Objects.equals(runCreationDate, runEntity.runCreationDate) &&
                Objects.equals(runMasterRun, runEntity.runMasterRun) &&
                Objects.equals(runCreatedBy, runEntity.runCreatedBy) &&
                Objects.equals(runExposureMetric, runEntity.runExposureMetric) &&
                Objects.equals(runAttainedAgeDef, runEntity.runAttainedAgeDef) &&
                Objects.equals(runAutRiskAmountChangeSplit, runEntity.runAutRiskAmountChangeSplit) &&
                Objects.equals(runByCountAnalysis, runEntity.runByCountAnalysis) &&
                Objects.equals(runByAmountAnalysis, runEntity.runByAmountAnalysis) &&
                Objects.equals(runByAmountAnalysisBasis, runEntity.runByAmountAnalysisBasis) &&
                Objects.equals(runByAmountCapped, runEntity.runByAmountCapped) &&
                Objects.equals(runLossRatioAnalysis, runEntity.runLossRatioAnalysis) &&
                Objects.equals(runLossRatioAnalysisBasis, runEntity.runLossRatioAnalysisBasis) &&
                Objects.equals(runCappedAmount, runEntity.runCappedAmount) &&
                Objects.equals(runIbnrManuelUdf, runEntity.runIbnrManuelUdf) &&
                Objects.equals(runIbnrAmount, runEntity.runIbnrAmount) &&
                Objects.equals(runIbnrAllocation, runEntity.runIbnrAllocation) &&
                Objects.equals(runFilterJsonUrl, runEntity.runFilterJsonUrl);
    }

    @Override
    public int hashCode() {

        return Objects.hash(runId, runRimId, runCode, runDescription, runStatus, runCreationDate, runMasterRun, runCreatedBy, runExposureMetric, runAttainedAgeDef, runAutRiskAmountChangeSplit, runByCountAnalysis, runByAmountAnalysis, runByAmountAnalysisBasis, runByAmountCapped, runLossRatioAnalysis, runLossRatioAnalysisBasis, runCappedAmount, runIbnrManuelUdf, runIbnrAmount, runIbnrAllocation, runFilterJsonUrl);
    }

    @Basic
    @Column(name = "RUN_DS_ID")
    public Integer getRunDsId() {
        return runDsId;
    }

    public void setRunDsId(Integer runDsId) {
        this.runDsId = runDsId;
    }

    @Basic
    @Column(name = "RUN_ST_ID")
    public Integer getRunStId() {
        return runStId;
    }

    public void setRunStId(Integer runStId) {
        this.runStId = runStId;
    }


    @OneToMany(cascade = CascadeType.ALL ,orphanRemoval = true)
    @JoinColumn(name = "DP_RUN_ID")
    public Collection<DecrementParametersEntity> getDecrementParametersByRunId() {
        return decrementParametersByRunId;
    }

    public void setDecrementParametersByRunId(Collection<DecrementParametersEntity> decrementParametersByRunId) {
        this.decrementParametersByRunId = decrementParametersByRunId;
    }
}
