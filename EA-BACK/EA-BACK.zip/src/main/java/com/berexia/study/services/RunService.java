package com.berexia.study.services;

import com.berexia.study.entities.RefLobEntity;
import com.berexia.study.entities.RunCalcEntity;
import com.berexia.study.entities.RunEntity;
import com.berexia.study.repositories.BusinessRepository;
import com.berexia.study.repositories.RunCalcRepository;
import com.berexia.study.repositories.RunRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RunService {

    @Autowired
    private RunRepository repository;

    @Autowired
    private RunCalcRepository rp;

    public List<RunEntity> getAll()
    {
        List<RunEntity> list = new ArrayList<RunEntity>();

        for ( RunEntity run : repository.findAll())
        {
            list.add(run);
        }
        return list;
    }

    public RunEntity save(RunEntity run){
        System.out.println(run);
        return repository.save(run);
    }

    public RunCalcEntity getRunCalcById(Integer id){
        List<RunCalcEntity> calc = rp.findByRclcRunIdOrderByRclcStartDateDesc(id);
        return (!calc.isEmpty())?calc.get(0):null;
    }

    public List<RunEntity> getByDatasetId(Integer id)
    {
        return repository.findByRunDsId(id);
    }

    public List<RunEntity> getByStudyId(Integer id)
    {
        return repository.findByRunStId(id);
    }

    public RunEntity getByRunId (Integer id ) {return repository.findByRunId(id); }

    public void delete(int id)
    {
        repository.delete(id);
    }
}
