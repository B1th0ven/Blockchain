package com.berexia.ea.spark;

import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import com.berexia.ea.accumulators.EventAccumulator;
import com.berexia.ea.entities.*;
import org.apache.hadoop.util.hash.Hash;
import org.apache.parquet.Strings;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.sources.In;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.util.LongAccumulator;

import com.berexia.ea.accumulators.ControlResultAccumulator;
import com.berexia.ea.accumulators.HashMapAccumulator;
import com.berexia.ea.common.DataProduct;
import scala.Array;
import scala.Tuple2;

import static org.apache.spark.sql.functions.max;
import static org.apache.spark.sql.types.DataTypes.IntegerType;

public class FuncControls implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    public static  ControlResults run(String path,String path_prod, String type,String op_start,String op_end) throws IOException {
		JavaSparkContext sc = Connection.getContext();

		JavaRDD<String> data = sc.textFile(path);
		String header = data.first();
		List<String> names = Arrays.asList(header.toLowerCase().split(";", -1));
		
		JavaRDD<String> dataP = sc.textFile(path_prod);
		String headerP = dataP.first();
		List<String> namesP = Arrays.asList(headerP.toLowerCase().split(";", -1));

		ArrayList<ArrayList<String>> dates_to_comp = new ArrayList<>();
		dates_to_comp.add(new ArrayList<>(Arrays.asList("date_of_birth", "date_of_commencement")));
		dates_to_comp.add(
				new ArrayList<>(Arrays.asList("date_of_begin_current_condition", "date_of_end_current_condition")));
		dates_to_comp.add(new ArrayList<>(Arrays.asList("date_of_commencement", "date_of_event_incurred")));
		dates_to_comp.add(new ArrayList<>(Arrays.asList("date_of_commencement", "cover_expiry_date")));
		dates_to_comp.add(new ArrayList<>(Arrays.asList("date_of_commencement", "date_of_begin_current_condition")));

        dates_to_comp.add(new ArrayList<>(Arrays.asList("date_of_event_incurred","cover_expiry_date"))); //sprint 3
		dates_to_comp.add(new ArrayList<>(Arrays.asList("date_of_end_current_condition","cover_expiry_date"))); //sprint3
		dates_to_comp.add(new ArrayList<>(Arrays.asList("date_of_event_incurred","date_of_event_notified","date_of_event_settled","date_of_event_paid"))); //sprint3



		ArrayList<ArrayList<String>> floats_to_comp = new ArrayList<>();
		floats_to_comp.add(new ArrayList<>(Arrays.asList("risk_amount_reinsurer", "risk_amount_insurer")));

		ArrayList<ArrayList<String>> dates_to_com_to_input = new ArrayList<>();
		dates_to_com_to_input.add(new ArrayList<>(Arrays.asList("start_of_observation_period","cover_expiry_date")));
		dates_to_com_to_input.add(new ArrayList<>(Arrays.asList("date_of_end_current_condition","end_of_observation_period")));
		dates_to_com_to_input.add(new ArrayList<>(Arrays.asList("start_of_observation_period","date_of_begin_current_condition")));




		ArrayList<String> risks_to_com = new ArrayList<>();
		risks_to_com.add("cici");
		risks_to_com.add("cilifeci");
		risks_to_com.add("tpdtpd");
		risks_to_com.add("tpdlifetpd");
		risks_to_com.add("ltcltc");
		risks_to_com.add("ltclifeltc");
		risks_to_com.add("lifecici");
		risks_to_com.add("lifecilifeci");
		risks_to_com.add("lifetpdtpd");
		risks_to_com.add("lifetpdlifetpd");
		risks_to_com.add("lifeltcltc");
		risks_to_com.add("lifeltclifeltc");

		ControlResultAccumulator dc_acc = new ControlResultAccumulator(
				new ControlResult("Date Comparison", new ArrayList<>()));
		sc.sc().register(dc_acc);

		ControlResultAccumulator fc_acc = new ControlResultAccumulator(
				new ControlResult("Amount Comparison", new ArrayList<>()));
		sc.sc().register(fc_acc);

		ControlResultAccumulator cc_acc = new ControlResultAccumulator(
				new ControlResult("Consistenct Check", new ArrayList<>()));
		sc.sc().register(cc_acc);
		
		ControlResultAccumulator overlap_acc = new ControlResultAccumulator(
				new ControlResult("Overlap Check", new ArrayList<>()));
		sc.sc().register(overlap_acc);

		ControlResultAccumulator eec_acc = new ControlResultAccumulator(
				new ControlResult("Event Existence Check", new ArrayList<>()));
		sc.sc().register(eec_acc);
		
		ControlResultAccumulator active_acc = new ControlResultAccumulator(
				new ControlResult("No exposure following terminating status at end condition", new ArrayList<>()));
		sc.sc().register(active_acc);
		
		ControlResultAccumulator coh_acc = new ControlResultAccumulator(
				new ControlResult("Status coherent with event type", new ArrayList<>()));
		sc.sc().register(coh_acc);

		ControlResultAccumulator claims_acc = new ControlResultAccumulator(
				new ControlResult("Claims existence check", new ArrayList<>()));
		sc.sc().register(claims_acc); //sprint 3

		ControlResultAccumulator lum_sum_acc = new ControlResultAccumulator(
				new ControlResult("Lump sum",new ArrayList<>()));
		sc.sc().register(lum_sum_acc);

		ControlResultAccumulator exposure_coherent_status = new ControlResultAccumulator(
				new ControlResult("Exposure end coherent with status",new ArrayList<>())	);
		sc.sc().register(exposure_coherent_status);

		LongAccumulator errorsCount = sc.sc().longAccumulator();

		EventAccumulator eventsAcc = new EventAccumulator();
		sc.sc().register(eventsAcc); //sprint 3

		data.cache();

		data.foreach(new VoidFunction<String>() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void call(String row) throws Exception {
				if (!row.equals("") & !row.equalsIgnoreCase(header)) {
					String[] row_arr = row.toLowerCase().trim().split(";", -1);


					HashMap<String,List<Event>> events = eventsAcc.value(); // sprint 3 events

                    // sprint 3 : claims existence
					if(names.indexOf("life_id") != -1 && names.indexOf("policy_id") != -1 && !row_arr[names.indexOf("type_of_event")].isEmpty() && !row_arr[names.indexOf("date_of_event_incurred")].isEmpty()
							&& !row_arr[names.indexOf("policy_id")].isEmpty() && !row_arr[names.indexOf("life_id")].isEmpty() && !row_arr[names.indexOf("main_risk_type")].isEmpty()){
						Event e = new Event(row_arr[names.indexOf("type_of_event")],
								row_arr[names.indexOf("date_of_event_incurred")],
								row_arr[names.indexOf("policy_id")],
								row_arr[names.indexOf("main_risk_type")],
								row_arr[names.indexOf("acceleration_risk_type")]);

						List<Event> evs = new ArrayList<Event>() ;
						if(events.containsKey(row_arr[names.indexOf("life_id")]))
						evs = events.get(row_arr[names.indexOf("life_id")]);
						if(!evs.contains(e))
						evs.add(e);
						HashMap<String, List<Event>> ev_add = new HashMap<>();
						ev_add.put(row_arr[names.indexOf("life_id")],evs);
						eventsAcc.add(ev_add);
					}

					//When death / withdrawal (lump sum), Risk Amount = Event Amount sprint 3
					if(names.containsAll(Arrays.asList("expenses_included","settlement_decision","event_amount_insurer","risk_amount_insurer","event_amount_reinsurer","risk_amount_reinsurer"))){
						String te = row_arr[names.indexOf("type_of_event")];
						String ei = row_arr[names.indexOf("expenses_included")];
						String sd = row_arr[names.indexOf("settlement_decision")];
						String eai = row_arr[names.indexOf("event_amount_insurer")].replace(",",".");
						String rai = row_arr[names.indexOf("risk_amount_insurer")].replace(",",".");
						String eari = row_arr[names.indexOf("event_amount_reinsurer")].replace(",",".");
						String rari = row_arr[names.indexOf("risk_amount_reinsurer")].replace(",",".");

						if(!eai.isEmpty() && !rai.isEmpty() && !eari.isEmpty() && !rari.isEmpty()){
						if((te.equalsIgnoreCase("death") || te.equalsIgnoreCase("withdrawal")) && ei.equalsIgnoreCase("no")){
							if(sd.equalsIgnoreCase("yes")){
								if(Float.parseFloat(eai) > Float.parseFloat(rai) || Float.parseFloat(eari) > Float.parseFloat(rari)){
									List<AffectedColumn> affectedColumns = new ArrayList<>();
									affectedColumns.add(new AffectedColumn("when death / withdrawal (lump sum), risk amount = event amount", 1,
											new ArrayList<>(Arrays.asList(row))));
									lum_sum_acc.add(new ControlResult("Lump sum", affectedColumns));
									errorsCount.add(1);
								}
							} else {
								if(!(Float.parseFloat(eai) == Float.parseFloat(rai)) || !(Float.parseFloat(eari) == Float.parseFloat(rari))){
									List<AffectedColumn> affectedColumns = new ArrayList<>();
									affectedColumns.add(new AffectedColumn("when death / withdrawal (lump sum), risk amount = event amount", 1,
											new ArrayList<>(Arrays.asList(row))));
									lum_sum_acc.add(new ControlResult("Lump sum", affectedColumns));
									errorsCount.add(1);
								}
							}
						}
					}


					}

                    for (ArrayList<String> dtc : dates_to_comp) {

						if (names.containsAll(dtc)) {

							ArrayList<LocalDate> dates = new ArrayList<>();
							boolean empty = false;
							for (String col : dtc) {
								if (names.indexOf(col) == -1) {
									empty = true;
									break;
								} else if (!row_arr[names.indexOf(col)].matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$")) {
									empty = true;
									break;
								}
								dates.add(LocalDate.parse(row_arr[names.indexOf(col)],
										DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH)));
							}
							if (empty)
								continue;
							for (int j = 0; j < dates.size() - 1; j++) {
								if (dates.get(j).isAfter(dates.get(j + 1))) {
									List<AffectedColumn> affectedColumns = new ArrayList<>();
									affectedColumns.add(new AffectedColumn(String.join(" & ", dtc.stream().map(s -> s.replace("_"," ")).collect(Collectors.toList())), 1,
											new ArrayList<>(Arrays.asList(row))));
									dc_acc.add(new ControlResult("Date Comparison", affectedColumns));
									errorsCount.add(1);
									break;
								}
							}
						}

					}


					//sprint 3 controles
					//Start of observation period ≤ Cover Expiry Date
					//Date of End Current Condition <= End of observation Period
					//Start of observation period) <= Date of Begin Current Condition

					if(!((op_start == null || op_start.isEmpty()) && (op_end == null || op_end.isEmpty()))){
						for(ArrayList<String> dtci : dates_to_com_to_input){
							ArrayList<LocalDate> dts = new ArrayList<>();
							for(String d : dtci){

								if(d.equalsIgnoreCase("start_of_observation_period") && !(op_start == null || op_start.isEmpty()) && op_start.matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$"))
									dts.add(LocalDate.parse(op_start,
											DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH)));
								else if(d.equalsIgnoreCase("end_of_observation_period") && !(op_end == null || op_end.isEmpty()) && op_end.matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$"))
									dts.add(LocalDate.parse(op_end,
											DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH)));
								else if(names.indexOf(d) != -1 && !row_arr[names.indexOf(d)].isEmpty() && row_arr[names.indexOf(d)].matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$"))
									dts.add(LocalDate.parse(row_arr[names.indexOf(d)],
											DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH)));
							}
							if(dts.size() == 2){
								if(dts.get(0).isAfter(dts.get(1))) {

									List<AffectedColumn> affectedColumns = new ArrayList<>();
									affectedColumns.add(new AffectedColumn(dtci.get(0).replace("_"," ") +" <= "+dtci.get(1).replace("_"," ") , 1,
										new ArrayList<>(Arrays.asList(row))));
									dc_acc.add(new ControlResult("Date Comparison", affectedColumns));
									errorsCount.add(1);
								}
							}
						}
					}


					for (ArrayList<String> ftc : floats_to_comp) {
						if (names.containsAll(ftc)) {
							ArrayList<Float> floats = new ArrayList<>();
							boolean empty = false;
							for (String col : ftc) {
								if (names.indexOf(col) == -1) {
									empty = true;
									break;
								} else if (row_arr[names.indexOf(col)].equals("")) {
									empty = true;
									break;
								}
								floats.add(Float.parseFloat(row_arr[names.indexOf(col)].replaceAll("\\,", "\\.")));
							}
							if (empty)
								continue;
							for (int j = 0; j < floats.size() - 1; j++) {
								if (floats.get(j) > floats.get(j + 1)) {
									List<AffectedColumn> affectedColumns = new ArrayList<>();
									affectedColumns.add(new AffectedColumn(String.join(" & ", ftc.stream().map(s -> s.replace("_"," ")).collect(Collectors.toList())), 1,
											new ArrayList<>(Arrays.asList(row))));
									fc_acc.add(new ControlResult("Amount Comparison", affectedColumns));
									errorsCount.add(1);
									break;
								}
							}
						}
					}
					
					//  EVENT EXISTENCE AT ALL STATUS CHANGES :
					String begin_stat = row_arr[names.indexOf("status_begin_current_condition")];
					String end_stat = row_arr[names.indexOf("status_end_current_condition")];

					if (type.equalsIgnoreCase("combine") & !begin_stat.equals(end_stat)
							& ("".equals(row_arr[names.indexOf("date_of_event_incurred")])
									|| "".equals(row_arr[names.indexOf("type_of_event")]))
							& !Arrays.asList("censored" , "expired").contains(end_stat)
									) {
                        //System.out.println("censored & expired != "+end_stat);
						List<AffectedColumn> affectedColumns = new ArrayList<>();
						affectedColumns.add(new AffectedColumn("date of event incurred & type of event", 1,
								new ArrayList<>(Arrays.asList(row))));
						eec_acc.add(new ControlResult("Event Existence Check", affectedColumns));
						errorsCount.add(1);
					}
					
					//  STATUS AT BEGIN SHOULD BE ALWAYS ACTIVE :
					if(!"Active".equalsIgnoreCase(begin_stat)) {
						List<AffectedColumn> affectedColumns = new ArrayList<>();
						affectedColumns.add(new AffectedColumn("exposure termination", 1,
								new ArrayList<>(Arrays.asList(row))));
						active_acc.add(new ControlResult("No exposure following terminating status at end condition", affectedColumns));
						errorsCount.add(1);
					}

					//  Status coherent with event type  :
					
					HashMap<String, String> status_type = new HashMap<>() ;
					status_type.put("active", "") ;
					status_type.put("claimant", "incidence") ;
					status_type.put("dead", "death") ;
					status_type.put("withdrawn", "withdrawal") ;
					status_type.put("expired", "") ;
					status_type.put("censored", "") ;
					
					if( type.equalsIgnoreCase("combine") 
							&  !row_arr[names.indexOf("type_of_event")].trim().equalsIgnoreCase(status_type.get(row_arr[names.indexOf("status_end_current_condition")].trim()))
							) {

						
						List<AffectedColumn> affectedColumns = new ArrayList<>();
						affectedColumns.add(new AffectedColumn("Type of Event & Status at End Current Condition", 1,
								new ArrayList<>(Arrays.asList(row))));
						coh_acc.add(new ControlResult("Status coherent with event type", affectedColumns));
						errorsCount.add(1);
					}
					

					if (names.containsAll(
							Arrays.asList("date_of_birth" ))
							& namesP.containsAll(Arrays.asList("age_definition"))
							) {

						List<Product> products = DataProduct.getProd(path_prod);


						String DOB_s = row_arr[names.indexOf("date_of_birth")];
						String prod_id = row_arr[names.indexOf("product_id")];
						String age_def = null;
						for (Product prod : products) {
							if (prod_id != null) {
								if( prod_id.equalsIgnoreCase(prod.getId()))
								{age_def = prod.getAge_def();
								break;}
							}
						}
						if(names.containsAll(Arrays.asList("age_at_commencement"))){
						String AAC_s = row_arr[names.indexOf("age_at_commencement")];
						String DC_s = row_arr[names.indexOf("date_of_commencement")];
						if (AAC_s.matches("^\\-?\\d+\\,?\\d*$") & DC_s.matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$")
								& DOB_s.matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$") & age_def != null) {
							int AAC = Integer.parseInt(AAC_s);
							LocalDate DC = LocalDate.parse(DC_s, DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH));
							LocalDate DOB = LocalDate.parse(DOB_s, DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH));

							long daysBetween = ChronoUnit.DAYS.between(DOB, DC);
							double age = daysBetween / (double) 365;
							int calculatedAge = 0;

							switch (age_def) {
								case "age last birthday":
									calculatedAge = (int) age;
									break;
								case "age nearest birthday":
									calculatedAge = (int) Math.round(age);
									break;
								case "age next birthday":
									calculatedAge = (int) age + 1;
									break;
								default:
									break;
							}
							if (AAC != calculatedAge) {
								List<AffectedColumn> affectedColumns = new ArrayList<>();
								affectedColumns.add(new AffectedColumn("date of commencement = age at commencement - date of birth", 1,
										new ArrayList<>(Arrays.asList(row))));
								dc_acc.add(new ControlResult("Date Comparison", affectedColumns));
								errorsCount.add(1);
							}
						}
					}

					//sprint 3 	Cover Expiry Date - Date of Birth <= Cover Expiry Age

					if( DOB_s.matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$") & age_def != null && names.containsAll(Arrays.asList("cover_expiry_date")) && names.containsAll(Arrays.asList("cover_expiry_age")) && row_arr[names.indexOf("cover_expiry_age")].matches("^\\-?\\d+\\,?\\d*$") ){

						int coverExpiryAge = 0;
						int cea= Integer.parseInt(row_arr[names.indexOf("cover_expiry_age")]);
						LocalDate ced = LocalDate.parse(row_arr[names.indexOf("cover_expiry_date")], DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH));
						LocalDate dob = LocalDate.parse(row_arr[names.indexOf("date_of_birth")], DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH));

						long daysBetween = ChronoUnit.DAYS.between(dob, ced);
						double age = daysBetween / (double) 365;
						switch (age_def) {
							case "age last birthday":
								coverExpiryAge = (int) age;
								break;
							case "age nearest birthday":
								coverExpiryAge = (int) Math.round(age);
								break;
							case "age next birthday":
								coverExpiryAge = (int) age + 1;
								break;
							default:
								break;
						}


						if(cea < coverExpiryAge){
							List<AffectedColumn> affectedColumns = new ArrayList<>();
							affectedColumns.add(new AffectedColumn("cover expiry date - date of birth <= cover expiry age", 1,
									new ArrayList<>(Arrays.asList(row))));
							dc_acc.add(new ControlResult("Date Comparison", affectedColumns));
							errorsCount.add(1);
						}
					}

					}
				}
			}
		});



		if (names.containsAll(Arrays.asList("life_id", "policy_id"))) {
			// before all we need to sort our rdd by date of start of current condition :
			JavaRDD<String> data_sorted = data.sortBy(new Function<String, Long>() {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;

				@Override
				public Long call(String line) throws Exception {
				//	System.out.println(Arrays.toString(line.split(";")));
					//System.out.println("******************"+names.indexOf("date of begin current condition"));
					//System.out.println(line.split(";").length);
					String sdate = "";
					if(0 <= names.indexOf("date_of_begin_current_condition") && names.indexOf("date_of_begin_current_condition") <= line.split(";").length-1)
					{sdate = line.split(";")[names.indexOf("date_of_begin_current_condition")];}
					if (sdate.matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$")) {
						SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
						Date date = formatter.parse(sdate);
						return date.getTime();
					} else
						return 999999999999L;
				}

			}, true, data.getNumPartitions());

			HashMapAccumulator hm_acc = new HashMapAccumulator();
			sc.sc().register(hm_acc);
			
			HashMapAccumulator hm_acc_date = new HashMapAccumulator();
			sc.sc().register(hm_acc_date);

			HashMapAccumulator hm_acc_last_line_id = new HashMapAccumulator();
			sc.sc().register(hm_acc_last_line_id);


			HashMap<String,List<Event>> hmp_events = eventsAcc.value(); // sprint 3 events

					data_sorted.foreach(new VoidFunction<String>() {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;

				@Override
				public void call(String row) throws Exception {
					if (!row.equals("") & !row.equalsIgnoreCase(header)) {
						String[] row_arr = row.toLowerCase().trim().split(";", -1);
						if (names.containsAll(Arrays.asList("benefit_id"))) {
							if (!row_arr[names.indexOf("life_id")].isEmpty() && !row_arr[names.indexOf("policy_id")].isEmpty() && !row_arr[names.indexOf("benefit_id")].isEmpty()) {
								String id = row_arr[names.indexOf("life_id")] + row_arr[names.indexOf("policy_id")]
										+ row_arr[names.indexOf("benefit_id")];
								String begin_stat = row_arr[names.indexOf("status_begin_current_condition")];
								String end_stat = row_arr[names.indexOf("status_end_current_condition")];

								String date_begin = row_arr[names.indexOf("date_of_begin_current_condition")];

								HashMap<String, String> val = hm_acc.value();

								if (val.containsKey(id)) {
									if (!val.get(id).equalsIgnoreCase(begin_stat)) {
										List<AffectedColumn> affectedColumns = new ArrayList<>();
										affectedColumns.add(new AffectedColumn(
												"status at begin current condition & status at end current condition", 1,
												new ArrayList<>(Arrays.asList(row))));
										cc_acc.add(new ControlResult("Status Consistency Check", affectedColumns));
										errorsCount.add(1);
									}
								}
								HashMap<String, String> curr = new HashMap<>();
								curr.put(id, end_stat);
								hm_acc.add(curr);


								if (names.containsAll(Arrays.asList("date_of_end_current_condition"))) {
									HashMap<String, String> val_date = hm_acc_date.value();
									String date_end = row_arr[names.indexOf("date_of_end_current_condition")];
									if (val_date.containsKey(id)) {
										if (!val_date.get(id).equalsIgnoreCase(date_begin)) {
											List<AffectedColumn> affectedColumns = new ArrayList<>();
											affectedColumns.add(new AffectedColumn(
													"overlap check", 1,
													new ArrayList<>(Arrays.asList(row))));
											overlap_acc.add(new ControlResult("Overlap Check", affectedColumns));
											errorsCount.add(1);
										}
									}
									HashMap<String, String> curr_date = new HashMap<>();
									curr_date.put(id, date_end);
									hm_acc_date.add(curr_date);
								}
							}
						}


						// controle : claims existence sprint 3 (not optimised)

						if (hmp_events.containsKey(row_arr[names.indexOf("life_id")]) && 0 <= names.indexOf("date_of_end_current_condition") && !row_arr[names.indexOf("date_of_begin_current_condition")].isEmpty() && !row_arr[names.indexOf("date_of_end_current_condition")].isEmpty()) {
							if(row_arr[names.indexOf("date_of_begin_current_condition")].matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$") && row_arr[names.indexOf("date_of_end_current_condition")].matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$") ){
							LocalDate start = LocalDate.parse(row_arr[names.indexOf("date_of_begin_current_condition")],
									DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH));
							LocalDate end = LocalDate.parse(row_arr[names.indexOf("date_of_end_current_condition")],
									DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH));
							//	System.out.println("***************************"+hmp_events.get(row_arr[names.indexOf("life id")]).size());
							if (hmp_events.get(row_arr[names.indexOf("life_id")]).size() > 0) {
								for (Event e : hmp_events.get(row_arr[names.indexOf("life_id")])) {
									LocalDate e_date = e.getDate();
									if(e_date != null){

										if (!row_arr[names.indexOf("policy_id")].isEmpty() && !row_arr[names.indexOf("policy_id")].equalsIgnoreCase(e.getPolicyID()) &&
											(e_date.isAfter(start) || e_date.isEqual(start)) && (end.isAfter(e_date) || end.isEqual(e_date))) {

											switch (e.getName()) {
											case "death":
												if (!row_arr[names.indexOf("main_risk_type")].isEmpty() && row_arr[names.indexOf("main_risk_type")].equalsIgnoreCase("life") && !row_arr[names.indexOf("type_of_event")].equalsIgnoreCase(e.getName())) {
													List<AffectedColumn> affectedColumns = new ArrayList<>();
													affectedColumns.add(new AffectedColumn(
															"claims existence", 1,
															new ArrayList<>(Arrays.asList(row))));
													claims_acc.add(new ControlResult("Claims existence", affectedColumns));
													errorsCount.add(1);
												}
												break;
											case "incidence":

												String risk = e.getMain_risk_type() + e.getAcceleration_risk_type() + row_arr[names.indexOf("main_risk_type")] + row_arr[names.indexOf("acceleration_risk_type")];
												risk = risk.replaceAll("\\s+", "");

												if (risks_to_com.contains(risk) && !row_arr[names.indexOf("type_of_event")].equalsIgnoreCase(e.getName())) {

													List<AffectedColumn> affectedColumns = new ArrayList<>();
													affectedColumns.add(new AffectedColumn(
															"claims existence", 1,
															new ArrayList<>(Arrays.asList(row))));
													claims_acc.add(new ControlResult("Claims existence", affectedColumns));
													errorsCount.add(1);
												}
												break;
											default:
												break;
										}
									}
								}
								}
							}
						}
					}
                   }
				}
			});



			if(names.containsAll(Arrays.asList("benefit_id","date_of_end_current_condition"))){

			    	data.filter(s -> !s.toLowerCase().trim().replace(";","").equalsIgnoreCase(""))
						.map(s -> s.toLowerCase().trim().split(";", -1))
					    .mapToPair(new PairFunction<String[],String,String[]>() {
										/**
										 *
										 */
					                  private static final long serialVersionUID = 1L;

									@Override
									public Tuple2<String,String[]> call(String[] row) throws Exception {
										//System.out.println("*******************************" + Arrays.toString(row));
									String id = row[names.indexOf("life_id")] + row[names.indexOf("policy_id")] + row[names.indexOf("benefit_id")];
									return new Tuple2<>(id, row);

									}
				}).reduceByKey(new Function2<String[],String[],String[]>(){
										/**
										 *
										 */
										private static final long serialVersionUID = 1L;

										@Override
										public String[] call (String[] row1,String[] row2) throws Exception {
											SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
											Date date1;
											Date date2;
											if(names.indexOf("date_of_begin_current_condition") == -1 || !row1[names.indexOf("date_of_begin_current_condition")].matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$"))
												date1 = formatter.parse("01/01/1000");
											else
											 date1 = formatter.parse(row1[names.indexOf("date_of_begin_current_condition")]);

											if(names.indexOf("date_of_begin_current_condition") == -1 || !row2[names.indexOf("date_of_begin_current_condition")].matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$"))
												date2 = formatter.parse("01/01/1000");
											else
												date2 = formatter.parse(row2[names.indexOf("date_of_begin_current_condition")]);

											if(date1.getTime() > date2.getTime())
												return row1;
											else
												return row2;

										}
				}).foreach(new VoidFunction<Tuple2<String, String[]>>(){
					/**
					 *
					 */
					private static final long serialVersionUID = 1L;

					@Override
					public void call(Tuple2<String, String[]> input) throws Exception {
						String row = String.join(";",input._2);
						if (0 <= names.indexOf("date_of_end_current_condition") && !row.equals("") & !row.equalsIgnoreCase(header)) {
							String[] row_arr = row.toLowerCase().trim().split(";", -1);
								String decc =  row_arr[names.indexOf("date_of_end_current_condition")].trim();
								String secc = row_arr[names.indexOf("status_end_current_condition")].trim();

							if(decc.isEmpty()){
									if(!secc.isEmpty() && !secc.equalsIgnoreCase("active")){
									List<AffectedColumn> affectedColumns = new ArrayList<>();
									affectedColumns.add(new AffectedColumn("exposure end coherent with status", 1,
											new ArrayList<>(Arrays.asList(row))));
									exposure_coherent_status.add(new ControlResult("Exposure end coherent with status ", affectedColumns));
									errorsCount.add(1);
								}
								}
								if(!decc.isEmpty() && decc.matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$") && op_end != null && op_end.matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$")){
									LocalDate end = LocalDate.parse(decc,
											DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH));
									LocalDate opend = LocalDate.parse(op_end,
											DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH));
								//	System.out.println("**************************"+secc.equalsIgnoreCase("active"));

									if((secc.isEmpty() || secc.equalsIgnoreCase("active")) && !end.isEqual(opend)){
								//		System.out.println("**************************"+secc.isEmpty()+" "+end.isEqual(opend)+" "+ secc.equalsIgnoreCase("active"));

										List<AffectedColumn> affectedColumns = new ArrayList<>();
										affectedColumns.add(new AffectedColumn("exposure end coherent with status", 1,
												new ArrayList<>(Arrays.asList(row))));
										exposure_coherent_status.add(new ControlResult("Exposure end coherent with status ", affectedColumns));
										errorsCount.add(1);
									}

								}


						}

					}
				});


			}

		}

		List<ControlResult> controlResultsList = new ArrayList<>();
		controlResultsList.add(dc_acc.value());
		controlResultsList.add(fc_acc.value());
		controlResultsList.add(cc_acc.value());
		controlResultsList.add(eec_acc.value());
		controlResultsList.add(active_acc.value());
		controlResultsList.add(overlap_acc.value());
		controlResultsList.add(coh_acc.value());
		controlResultsList.add(claims_acc.value());
		controlResultsList.add(lum_sum_acc.value());
		controlResultsList.add(exposure_coherent_status.value());
		return new ControlResults(null, errorsCount.value(), controlResultsList, header);
	}
}
