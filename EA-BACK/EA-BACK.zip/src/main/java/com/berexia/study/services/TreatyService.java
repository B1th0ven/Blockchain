package com.berexia.study.services;

import com.berexia.study.repositories.TreatyRepository;
import com.berexia.study.entities.RefTreatyEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TreatyService {

    @Autowired
    private TreatyRepository treatyRepository;

    public List<RefTreatyEntity> getAllTreaties()
    {
        List<RefTreatyEntity> list = new ArrayList<RefTreatyEntity>();

        for ( RefTreatyEntity st : treatyRepository.findAll())
        {
            list.add(st);
        }
        return list;
    }

    public List<RefTreatyEntity> getAllTreatiesByClientId(int id) {
        List<RefTreatyEntity> list = new ArrayList<RefTreatyEntity>();

        for ( RefTreatyEntity st : treatyRepository.findByRtRcnId(id))
        {
            list.add(st);
        }
        return list;
    }
}
