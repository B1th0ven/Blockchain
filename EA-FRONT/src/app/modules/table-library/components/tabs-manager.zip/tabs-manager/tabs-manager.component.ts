import {
  Component,
  OnInit
} from '@angular/core';
import {
  Tab
} from '../../models/tab.class';
import {
  TAB_TYPE
} from '../../enums/tab.enum';
import {
  ExpectedTable
} from '../../models/expected-table.model';
import {
  TablesService
} from '../../services/tables.service';

@Component({
  selector: 'app-tabs-manager',
  templateUrl: './tabs-manager.component.html',
  styleUrls: ['./tabs-manager.component.scss']
})
export class TabsManagerComponent implements OnInit {

  tabs: Tab[]

  activeTab = 0

  constructor(private ets: TablesService) {}

  ngOnInit() {
    this.tabs = new Array < Tab > ()
    this.tabs.push({
      name: "Table Library Management",
      type: TAB_TYPE.SHOW_LIST,
      entity: null
    })
  }

  openTab(i, event?: Event) {
    event.preventDefault()
    this.activeTab = i;
  }

  newTab(event) {
    if (event.entity && event.entity.id && this.tabs.find(t => t.entity && t.entity.id == event.entity.id)) {
      let tabIndex = this.tabs.findIndex(t => t.entity && t.entity.id == event.entity.id)
      if (event.open)
        this.activeTab = tabIndex
    } else {
      this.tabs.push({
        name: (event.entity) ? event.entity.name : "Tab Name",
        type: TAB_TYPE.CREATE,
        entity: event.entity
      })
      if (event.open)
        this.activeTab = this.tabs.length - 1
    }

  }

  closeTab(i, e ? ) {
    if (e)
      e.preventDefault();

    if (this.activeTab >= i && this.activeTab > 0 && this.tabs.length)
      this.activeTab--;
    this.tabs.splice(i, 1);
  }

  onSave(event, tab,i?) {
    tab.entity = event.table
    tab.name = (event.table) ? event.table.name : "ERROR";

    let pCode = this.getPrefix(event.previousCode)
    let nCode = this.getPrefix(event.table.code)

    this.tabs.forEach(ti => {

      if (ti.entity && ti.entity.id && ti.entity.id != event.table.id ) {
        let code = this.getPrefix(ti.entity.code)
        if ( code == pCode || code == nCode )
          this.ets.getOneTable(ti.entity.id).subscribe((res: ExpectedTable) => {
            ti.entity.latest_version = res.latest_version
          })
      }
    });

    if ( i ){
      this.closeTab(i)
      this.openTab(0)
    }
  }

  private getPrefix(code: any) {
    let p = String(code).split("_").slice(0, -1).join("_");
    return p
  }
}
