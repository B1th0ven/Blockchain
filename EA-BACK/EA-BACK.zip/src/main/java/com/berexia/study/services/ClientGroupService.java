package com.berexia.study.services;

import com.berexia.study.repositories.ClientGroupRepository;
import com.berexia.study.entities.RefParentGroupEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ClientGroupService {

    @Autowired
    private ClientGroupRepository repository;

    public List<RefParentGroupEntity> getAll()
    {
        List<RefParentGroupEntity> list = new ArrayList<RefParentGroupEntity>();

        for ( RefParentGroupEntity st : repository.findAll())
        {
            list.add(st);
        }
        return list;
    }
}
