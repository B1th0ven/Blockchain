package com.berexia.study.entities;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "REF_USER", schema = "dbo", catalog = "EXPAN")
public class RefUserEntity {
    private int ruId;
    private String ruFirstName;
    private String ruLastName;
    private Integer ruRmId;
    private String ruLogin;
    private RefMarketEntity refMarketByRuRmId;

    @Id
    @Column(name = "RU_ID")
    public int getRuId() {
        return ruId;
    }

    public void setRuId(int ruId) {
        this.ruId = ruId;
    }

    @Basic
    @Column(name = "RU_FIRST_NAME")
    public String getRuFirstName() {
        return ruFirstName;
    }

    public void setRuFirstName(String ruFirstName) {
        this.ruFirstName = ruFirstName;
    }

    @Basic
    @Column(name = "RU_LAST_NAME")
    public String getRuLastName() {
        return ruLastName;
    }

    public void setRuLastName(String ruLastName) {
        this.ruLastName = ruLastName;
    }

    @Basic
    @Column(name = "RU_RM_ID")
    public Integer getRuRmId() {
        return ruRmId;
    }

    public void setRuRmId(Integer ruRmId) {
        this.ruRmId = ruRmId;
    }

    @Basic
    @Column(name = "RU_LOGIN")
    public String getRuLogin() {
        return ruLogin;
    }

    public void setRuLogin(String ruLogin) {
        this.ruLogin = ruLogin;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RefUserEntity that = (RefUserEntity) o;
        return ruId == that.ruId &&
                Objects.equals(ruFirstName, that.ruFirstName) &&
                Objects.equals(ruLastName, that.ruLastName) &&
                Objects.equals(ruRmId, that.ruRmId) &&
                Objects.equals(ruLogin, that.ruLogin);
    }

    @Override
    public int hashCode() {

        return Objects.hash(ruId, ruFirstName, ruLastName, ruRmId, ruLogin);
    }

    @ManyToOne
    @JoinColumn(name = "RU_RM_ID", referencedColumnName = "RM_ID" , insertable = false ,updatable = false)
    public RefMarketEntity getRefMarketByRuRmId() {
        return refMarketByRuRmId;
    }

    public void setRefMarketByRuRmId(RefMarketEntity refMarketByRuRmId) {
        this.refMarketByRuRmId = refMarketByRuRmId;
    }
}
