package com.berexia.ea.ibrn;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
public class IbnrController {

    @Autowired
    IbnrService service;
    @RequestMapping(value="ibnr/compulsory",method = RequestMethod.POST)
    public List<String> ibnrCompControl(HttpEntity<String> req) throws Exception
    {
        HashMap<String, Object> req_map = new ObjectMapper().readValue(req.getBody() , HashMap.class) ;
        String path = (String) req_map.get("path") ;
        String type = (String) req_map.get("type") ;

        return service.compoloryCheck(path,type);
    }

    @RequestMapping(value="ibnr/technical",method = RequestMethod.POST)
    public List<String> ibnrPossibleValuesControl(HttpEntity<String> req) throws Exception
    {
        HashMap<String, Object> req_map = new ObjectMapper().readValue(req.getBody() , HashMap.class) ;
        String path = (String) req_map.get("path") ;
        String type = (String) req_map.get("type") ;

        return service.techControls(path,type);
    }

}
