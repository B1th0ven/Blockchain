package com.berexia.study.controllers;

import com.berexia.study.entities.RefParentGroupEntity;
import com.berexia.study.services.ClientGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ClientGroupController {

    @Autowired
    private ClientGroupService clientService;

    @RequestMapping("/groups")
    public List<RefParentGroupEntity> getGroups()
    {
        System.out.println("--------------------------------------------");
        return clientService.getAll();
    }
}
