package com.berexia.study.services;

import com.berexia.study.repositories.CalculationEngineRepository;
import com.berexia.study.entities.RefCalculationEngineTypeEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CalculationEngineService {

    @Autowired
    private CalculationEngineRepository repository;

    public List<RefCalculationEngineTypeEntity> getAll()
    {
        List<RefCalculationEngineTypeEntity> list = new ArrayList<RefCalculationEngineTypeEntity>();

        for ( RefCalculationEngineTypeEntity st : repository.findAll())
        {
            list.add(st);
        }
        return list;
    }
}
