package com.berexia.study.services;

import com.berexia.study.entities.*;
import com.berexia.study.repositories.ClientTypeRepository;
import com.berexia.study.repositories.CountryRepository;
import com.berexia.study.repositories.StudyRepository;
import com.berexia.study.specifications.GenericJoin;
import com.berexia.study.specifications.SearchCriteria;
import com.berexia.study.specifications.StudyEntityPage;
import com.berexia.study.specifications.StudySpecification;
import javafx.beans.binding.BooleanExpression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContexts;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.Metamodel;
import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class StudyService {

    final String QUERY_SEPERATOR = ";";

    @Autowired
    private StudyRepository studyRepository;

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private ClientTypeRepository clientTypeRepository;

    @PersistenceContext
    private EntityManager em;

    public StudyEntityPage searchByQuery(int page, int limit, Optional<String> code, Optional<String> country, Optional<String> group, Optional<String> client, Optional<String> brand, Optional<String> treaty, Optional<String> lob, Optional<String> status, Optional<String> statusDate, Optional<String> sort, Optional<Boolean> desc) {
        //Builder
        CriteriaBuilder cb = em.getCriteriaBuilder();

        //Criteria Queries
        CriteriaQuery<StudyEntity> q = cb.createQuery(StudyEntity.class);

        //Study Metadata
        Metamodel m = em.getMetamodel();
        EntityType<StudyEntity> StudyEntity_ = m.entity(StudyEntity.class);

        //Root
        Root<StudyEntity> studyEntities = q.from(StudyEntity_);

        //Predicate
        Predicate p = cb.and();//Always true

        //Code
        p = filter(code, "stCode", cb, studyEntities, p);
        //Brand
        p = filter(brand, "stDistributionBrand", cb, studyEntities, p);
        //Status
        p = filter(status, "stStatus", cb, studyEntities, p);
        //Status date
        p = filter(statusDate, "stLastStatusModificationDate", cb, studyEntities, p);

        //Country
        p = filterJoin(country, "refCountryById", "rcName", cb, studyEntities, p);
        //Parent Group
        p = filterJoinMOV(group, "refParentGroupByStRpgId", "rpgName", "stMultiParentGroup", "stOtherParentGroup", cb, studyEntities, p);
        //Clients
        p = filterJoinMOV(client, "refCedentNameByStRcnId", "rcnName", "stMultiCedent", "stOtherCedent", cb, studyEntities, p);
        //Treaty
        p = filterJoinMOV(treaty, "refTreatyByStRtId", "rtName", "stMultiTreaty", "stOtheriTreaty", cb, studyEntities, p);
        //lob
        p = filterJoinMultiple(lob, "refLobsById", "rlobName", cb, studyEntities, p, q);

        q.where(p);


        if (!sort.isPresent()) {
            sort(desc, cb, q, studyEntities, "stLastStatusModificationDate");
        } else {
            String sortColumnName = null;
            String sortMultiColumnName = null;
            String sortOtherColumnName = null;
            String joinColumnName = null;
            String multiSortColumnName = null;

            switch (sort.get()) {
                case "group":
                    sortColumnName = "rpgName";
                    joinColumnName = "refParentGroupByStRpgId";
                    sortMultiColumnName = "stMultiParentGroup";
                    sortOtherColumnName = "stOtherParentGroup";
                    break;
                case "client":
                    sortColumnName = "rcnName";
                    joinColumnName = "refCedentNameByStRcnId";
                    sortMultiColumnName = "stMultiCedent";
                    sortOtherColumnName = "stOtherCedent";
                    break;
                case "treaty":
                    sortColumnName = "rtName";
                    joinColumnName = "refTreatyByStRtId";
                    sortMultiColumnName = "stMultiTreaty";
                    sortOtherColumnName = "stOtheriTreaty";
                    break;
                case "country":
                    sortColumnName = "rcName";
                    joinColumnName = "refCountryById";
                    break;
                case "lob":
                    multiSortColumnName = "rlobName";
                    joinColumnName = "refLobsById";
                    break;
                case "code":
                    sortColumnName = "stCode";
                    break;
                case "status":
                    sortColumnName = "stStatus";
                    break;
                case "brand":
                    sortColumnName = "stDistributionBrand";
                    break;
                case "statusdate":
                default:
                    sortColumnName = "stLastStatusModificationDate";
            }

            if ( multiSortColumnName != null && joinColumnName != null ) {
                sortJoinMultiple(desc, cb, q, studyEntities, joinColumnName, multiSortColumnName);
            } else if (sortMultiColumnName != null && sortOtherColumnName != null) {
                sortJoinMOV(desc, cb, q, studyEntities, joinColumnName, sortColumnName, sortMultiColumnName, sortOtherColumnName);
            } else if (joinColumnName != null) {
                sortJoin(desc, cb, q, studyEntities, joinColumnName, sortColumnName);
            } else {
                sort(desc, cb, q, studyEntities, sortColumnName);
            }

        }


        Long totalPages;
        if (limit == 0) totalPages = 1L;
        else totalPages = (long) Math.ceil(((float) em.createQuery(q).getResultList().size()) / limit);

        TypedQuery<StudyEntity> tq = em.createQuery(q).setFirstResult(page * limit).setMaxResults(limit);
        List<StudyEntity> allStudents = tq.getResultList();

        StudyEntityPage returnPage = new StudyEntityPage(allStudents, totalPages);

        return returnPage;
    }

    private Predicate filterJoinMOV(Optional<String> query, String joinColumnName, String columnName, String multiColumn, String otherColumn, CriteriaBuilder cb, Root<StudyEntity> studyEntities, Predicate p) {
        if (query.isPresent()) {
            Predicate multi = cb.not(cb.and());
            Predicate other = cb.not(cb.and());

            String[] queryList = query.get().split(QUERY_SEPERATOR);

            final Join<Object, Object> join = studyEntities.join(joinColumnName, JoinType.LEFT);
            Predicate orp = cb.or();
            for (String q : queryList) {
                if ("multiple".contains(q.trim().toLowerCase()))
                    multi = cb.equal(studyEntities.get(multiColumn), true);
                if ("other".contains(q.trim().toLowerCase()))
                    other = cb.equal(studyEntities.get(otherColumn), true);

                orp = cb.or(orp, cb.like(join.get(columnName), "%" + q.trim() + "%"));
            }
            p = cb.and(p, cb.or(orp, cb.or(multi, other)));
        }
        return p;
    }

    private Predicate filterJoin(Optional<String> query, String joinColumnName, String columnName, CriteriaBuilder cb, Root<StudyEntity> studyEntities, Predicate p) {
        if (query.isPresent()) {
            String[] queryList = query.get().split(QUERY_SEPERATOR);
            final Join<Object, Object> join = studyEntities.join(joinColumnName, JoinType.LEFT);
            Predicate orp = cb.or();
            for (String q : queryList) {
                orp = cb.or(orp, cb.like(join.get(columnName), "%" + q.trim() + "%"));
            }
            p = cb.and(p, orp);
        }
        return p;
    }

    private Predicate filterJoinMultiple(Optional<String> query, String joinColumnName, String columnName, CriteriaBuilder cb, Root<StudyEntity> studyEntities, Predicate p, CriteriaQuery cq) {
        if (query.isPresent()) {
            String[] queryList = query.get().split(QUERY_SEPERATOR);
            Subquery<Long> sq = cq.subquery(Long.class);
            Root<StudyEntity> subStudy = sq.from(StudyEntity.class);
            final Join<Object, Object> join = studyEntities.join(joinColumnName, JoinType.LEFT);
            final Join<Object, Object> subjoin = subStudy.join(joinColumnName, JoinType.LEFT);

            Predicate andp = cb.or();//cb.equal(studyEntities.get("stId"),subStudy.get("stId"));
            System.out.println(Arrays.asList(queryList));
            for (String q : queryList) {
                andp = cb.or(andp, cb.like(subjoin.get(columnName), "%" + q.trim() + "%"));
            }

            sq.select(cb.count(subjoin.get("rlobId")))
                    .where(cb.and(cb.equal(studyEntities.get("stId"), subStudy.get("stId")), andp))
                    .groupBy(subStudy.get("stId"));

            p = cb.and(p, cb.greaterThanOrEqualTo(sq, Long.valueOf(queryList.length)));

            //cq.distinct(true);
            //groupStudy(studyEntities,join,columnName, cq);

        }

        return p;
    }

    private void groupStudy(Root<StudyEntity> studyEntities, Join<Object, Object> join, String columnName, CriteriaQuery cq) {
        cq.groupBy(
                studyEntities.get("stId"), studyEntities.get("stId"), studyEntities.get("stCode"), studyEntities.get("stRdsId"), studyEntities.get("stRpgId"), studyEntities.get("stRcnId"), studyEntities.get("stRcId"), studyEntities.get("stRlobId"), studyEntities.get("stRcetId"), studyEntities.get("stStcId"), studyEntities.get("stRtId"), studyEntities.get("stStatus"), studyEntities.get("stLastStatusModifiedBy"), studyEntities.get("stLastStatusModificationDate"), studyEntities.get("stStartObservationDate"), studyEntities.get("stEndObservationDate"), studyEntities.get("stMultiParentGroup"), studyEntities.get("stMultiCedent"), studyEntities.get("stMultiTreaty"), studyEntities.get("stOtherParentGroup"), studyEntities.get("stOtherCedent"), studyEntities.get("stOtheriTreaty"), studyEntities.get("stShortName"), studyEntities.get("stQualityDataProvider"), studyEntities.get("stDistributionBrand"), studyEntities.get("stAttachedFilePath"), studyEntities.get("stCreatedById"), studyEntities.get("stCreatedDate"), studyEntities.get("stComment"),
                join.get(columnName));
    }
    private void groupStudy(Root<StudyEntity> studyEntities,CriteriaQuery cq) {
        cq.groupBy(studyEntities.get("stId"), studyEntities.get("stId"), studyEntities.get("stCode"), studyEntities.get("stRdsId"), studyEntities.get("stRpgId"), studyEntities.get("stRcnId"), studyEntities.get("stRcId"), studyEntities.get("stRlobId"), studyEntities.get("stRcetId"), studyEntities.get("stStcId"), studyEntities.get("stRtId"), studyEntities.get("stStatus"), studyEntities.get("stLastStatusModifiedBy"), studyEntities.get("stLastStatusModificationDate"), studyEntities.get("stStartObservationDate"), studyEntities.get("stEndObservationDate"), studyEntities.get("stMultiParentGroup"), studyEntities.get("stMultiCedent"), studyEntities.get("stMultiTreaty"), studyEntities.get("stOtherParentGroup"), studyEntities.get("stOtherCedent"), studyEntities.get("stOtheriTreaty"), studyEntities.get("stShortName"), studyEntities.get("stQualityDataProvider"), studyEntities.get("stDistributionBrand"), studyEntities.get("stAttachedFilePath"), studyEntities.get("stCreatedById"), studyEntities.get("stCreatedDate"), studyEntities.get("stComment"));
    }

    private Predicate filter(Optional<String> query, String columnName, CriteriaBuilder cb, Root<StudyEntity> studyEntities, Predicate p) {

        if (query.isPresent()) {
            String[] queryList = query.get().split(QUERY_SEPERATOR);
            System.out.println(query.get() + "---------->" + Arrays.asList(queryList) + "---------------------------------------------------------------");
            Predicate orp = cb.or();
            for (String q : queryList) {
                orp = cb.or(orp, cb.like(studyEntities.get(columnName).as(String.class), "%" + q.trim() + "%"));
            }
            p = cb.and(p, orp);
        }
        return p;
    }

    private void sort(Optional<Boolean> desc, CriteriaBuilder cb, CriteriaQuery<StudyEntity> q, Root<StudyEntity> studyEntities, String sortColumnName) {
        Expression<Object> expression = cb.selectCase().when(cb.isNull(studyEntities.get(sortColumnName)), 3).otherwise(2);
        if (desc.isPresent() && desc.get() == true) {
            q.orderBy(
                    cb.desc(expression),
                    cb.desc(studyEntities.get(sortColumnName)),
                    cb.desc(studyEntities.get("stId")));
        } else {
            q.orderBy(
                    cb.asc(expression),
                    cb.asc(studyEntities.get(sortColumnName)),
                    cb.asc(studyEntities.get("stId")));
        }
        groupStudy(studyEntities, q);
        //q.select(studyEntities.get(sortColumnName)).select(studyEntities.get("stId"));
    }

    private void sortJoin(Optional<Boolean> desc, CriteriaBuilder cb, CriteriaQuery<StudyEntity> q, Root<StudyEntity> studyEntities, String joinColumnName, String sortColumnName) {
        Join<Object, Object> join = studyEntities.join(joinColumnName, JoinType.LEFT);
        if (desc.isPresent() && desc.get() == true) {
            q.orderBy(cb.desc(join.get(sortColumnName)), cb.desc(studyEntities.get("stId")));
        } else {
            q.orderBy(cb.asc(join.get(sortColumnName)), cb.asc(studyEntities.get("stId")));
        }
        groupStudy(studyEntities, join, sortColumnName, q);
    }

    private void sortJoinMultiple(Optional<Boolean> desc, CriteriaBuilder cb, CriteriaQuery<StudyEntity> q, Root<StudyEntity> studyEntities, String joinColumnName, String sortColumnName) {
        Join<Object, Object> join = studyEntities.join(joinColumnName, JoinType.LEFT);

        groupStudy(studyEntities, join, sortColumnName, q);

        if (desc.isPresent() && desc.get() == true) {
            q.orderBy(
                    cb.desc(cb.function("dbo.getLobsCount",Integer.class, studyEntities.get("stId") )),
                    cb.desc(cb.function("dbo.getLobsString",String.class, studyEntities.get("stId") ))
            );
        } else {
            q.orderBy(
                    cb.asc(cb.function("dbo.getLobsCount",Integer.class, studyEntities.get("stId") )),
                    cb.asc(cb.function("dbo.getLobsString",String.class, studyEntities.get("stId") ))
            );
        }

        //groupStudy(studyEntities,join,"rlobName" ,q);
        groupStudy(studyEntities,q);
    }

    private void sortJoinMOV(Optional<Boolean> desc, CriteriaBuilder cb, CriteriaQuery<StudyEntity> q, Root<StudyEntity> studyEntities, String joinColumnName, String sortColumnName, String sortMultiColumnName, String sortOtherColumnName) {
        Join<Object, Object> join = studyEntities.join(joinColumnName, JoinType.LEFT);
        Expression<Object> expression = cb.selectCase().when(cb.isTrue(studyEntities.get(sortOtherColumnName)), 1)
                .when(cb.isTrue(studyEntities.get(sortMultiColumnName)), 2)
                .when(cb.isNull(cb.trim(join.get(sortColumnName))), 3)
                .otherwise(0);
        if (desc.isPresent() && desc.get() == true) {
            q.orderBy(cb.desc(expression), cb.desc(join.get(sortColumnName)));
        } else {
            q.orderBy(cb.asc(expression), cb.asc(join.get(sortColumnName)));
        }
        groupStudy(studyEntities, join, sortColumnName, q);
    }


    public Page<StudyEntity> getPage(Pageable p) {
        return studyRepository.findAll(p);
    }

    public List<StudyEntity> getAllStudies() {
        List<StudyEntity> list = new ArrayList<StudyEntity>();

        for (StudyEntity st : studyRepository.findAll()) {
            list.add(st);
        }
        return list;
    }

    public StudyEntity getStudy(int id) {
        return null;
        //return studyRepository.findOne(id);
    }

    public StudyEntity postStudy(StudyEntity st) {
        String cCode = countryRepository.findOne(st.getStRcId()).getRcCode().trim();
        String cType = clientTypeRepository.findOne(st.getStStcId()).getStcCode().trim();
        String sName = st.getStShortName().trim();
        String year;

        SimpleDateFormat df = new SimpleDateFormat("yyyy");
        year = df.format(st.getStCreatedDate());

        String prefix = cCode + "_" + sName + "_" + cType + "_" + year + "_";

        System.out.println("----------" + prefix + " ------ " + st.getStCode());
        if (st.getStCode() != null && st.getStCode().substring(0, st.getStCode().length() - 3).equals(prefix)) {
            return studyRepository.save(st);
        }

        Optional<String> last = studyRepository.findLatestIdPrefix(prefix);

        if (last.isPresent()) {
            prefix = last.get();

            try {
                int num = Integer.parseInt(prefix.substring(prefix.length() - 3, prefix.length()));
                num++;
                st.setStCode(prefix.substring(0, prefix.length() - 3) + String.format("%03d", num));
            } catch (NumberFormatException e) {
                st.setStCode(prefix + "001");
            }
        } else {
            st.setStCode(prefix + "001");
        }


        return studyRepository.save(st);
    }
}
