package com.berexia.study.controllers;

import com.berexia.study.entities.RefLobEntity;
import com.berexia.study.services.BusinessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BusinessController {

    @Autowired
    private BusinessService service;

    @RequestMapping("/business")
    public List<RefLobEntity> getClients()
    {
        return service.getAll();
    }
}
