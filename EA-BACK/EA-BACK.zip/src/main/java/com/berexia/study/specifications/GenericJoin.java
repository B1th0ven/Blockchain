package com.berexia.study.specifications;


import org.apache.poi.ss.formula.functions.T;

import javax.persistence.criteria.Join;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Root;

public class GenericJoin {


}
