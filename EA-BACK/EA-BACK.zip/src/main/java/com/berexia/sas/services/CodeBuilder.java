package com.berexia.sas.services;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class CodeBuilder {
    private  String code;

    public CodeBuilder(){}

    private  void buildCode(String id,String drop_dim,String type) {



            Stream<String> lines = null ;
            try {
                lines = Files.lines( Paths.get( CodeBuilder.class.getClassLoader().getResource("data/run.sas").toURI() ), StandardCharsets.ISO_8859_1 );
                StringBuilder sb = new StringBuilder();

                lines.forEach(line ->{
                    if(!line.equals("")) {
                        String line_change_id = line.replaceAll("&",id);
                        String line_change_dim = line_change_id.replaceAll("#",drop_dim);
                        String line_change_type = line_change_dim.replaceAll("@",type);
                        sb.append(line_change_type);
                        sb.append("\n");

                    }
                });
                code = sb.toString();
            } catch (IOException | URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }


    }

    public String getCode(String id,String dim,String type){
        buildCode(id,dim,type);
        System.out.println(code);
        return code;
    }
}
