package com.berexia.file.controllers;

import com.berexia.file.services.FileService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;
import java.util.HashMap;


@RestController
public class SaveFileController {

    @Autowired
    private FileService fileService;

}
