package com.berexia.study.services;

import com.berexia.study.repositories.DataSourceRepository;
import com.berexia.study.entities.RefDataSourceEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DataSourceService {

    @Autowired
    private DataSourceRepository repository;

    public List<RefDataSourceEntity> getAll()
    {
        List<RefDataSourceEntity> list = new ArrayList<RefDataSourceEntity>();

        for ( RefDataSourceEntity st : repository.findAll())
        {
            list.add(st);
        }
        return list;
    }
}
