package com.berexia.ea.spark;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.berexia.ea.entities.PivotCol;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import com.berexia.ea.common.DataPivot;
import com.berexia.ea.common.DataProduct;
import com.berexia.ea.entities.Product;
import org.apache.spark.sql.catalyst.plans.logical.Pivot;

import javax.xml.crypto.Data;

public class CompColsCheck {

	 static JavaSparkContext sc = Connection.getContext();
	 static List<String> compCols = DataPivot.getCompCols();
	 static List<String> pivCols = DataPivot.getPivotCols().stream().map(s -> s.getName()).collect(Collectors.toList());
	 static List<String> compColsProduct = DataPivot.getCompColsProduct() ;
	 static List<String> pivColsProduct = DataPivot.getPivotColsProduct().stream().map(s -> s.getName()).collect(Collectors.toList());

	public  List<List<String>> run(String path, String type) {

		JavaRDD<String> data = sc.textFile(path);
		String header = data.first();

		List<String> cols = new ArrayList<String>(Arrays.asList(header.toLowerCase().trim().split(";",-1)));

		if (type.equalsIgnoreCase("combine"))
			cols.add("exposure_or_event");

		return Arrays.asList(
				new ArrayList<String>(pivCols.stream().filter(s -> cols.contains(s)).collect(Collectors.toList())),
				compCols.stream().filter(s -> !cols.contains(s)).collect(Collectors.toList()),
				cols.stream().filter(s -> !pivCols.contains(s)).collect(Collectors.toList())
				);
	}
	
	public  List<List<String>> runProduct(String path) {
		
		// Long start = System.currentTimeMillis() ;
		
		JavaRDD<String> data = sc.textFile(path);
		String header = data.first();
		
		List<String> cols = new ArrayList<String>(Arrays.asList(header.toLowerCase().trim().split(";")));
		
		return Arrays.asList(
				new ArrayList<String>(pivColsProduct.stream().filter(s -> cols.contains(s)).collect(Collectors.toList())),
				compColsProduct.stream().filter(s -> !cols.contains(s)).collect(Collectors.toList()),
				cols.stream().filter(s -> !pivColsProduct.contains(s)).collect(Collectors.toList())
				);
	}

	public  List<String> notExecutedCtrl(String path , String path_product , String type,String op_start, String op_end) throws IOException {

		JavaRDD<String> data = sc.textFile(path);
		JavaRDD<String> data_product = sc.textFile(path_product);
		
		String header = data.first();
		String header_product = data_product.first();

		List<String> cols = new ArrayList<String>(Arrays.asList(header.toLowerCase().trim().split(";")));
		List<String> cols_product = new ArrayList<String>(Arrays.asList(header_product.toLowerCase().trim().split(";")));
		
		List<String> notEcecuted = new ArrayList<>() ;

		if(!cols.containsAll(Arrays.asList("life_id", "policy_id", "benefit_id"))) notEcecuted.add("status at begin current condition & status at end current condition") ;
		if(!cols.containsAll(Arrays.asList("date_of_birth", "date_of_commencement"))) notEcecuted.add("date of birth & date of commencement") ;
		if(!cols.containsAll(Arrays.asList("risk_amount_reinsurer", "risk_amount_insurer"))) notEcecuted.add("risk amount reinsurer & risk amount insurer") ;
		if(!cols.containsAll(Arrays.asList("date_of_begin_current_condition", "date_of_end_current_condition"))) notEcecuted.add("date of begin current condition & date of end current condition") ;
		if(!cols.containsAll(Arrays.asList("life_id", "policy_id", "benefit_id","date_of_end_current_condition"))) notEcecuted.add("Overlap Check") ;
		if(!cols.containsAll(Arrays.asList("date_of_commencement", "date_of_event_incurred"))) notEcecuted.add("date of commencement <= date of event incurred") ;
		if(!cols.containsAll(Arrays.asList("date_of_commencement", "cover_expiry_date"))) notEcecuted.add("date of commencement & cover expiry date") ;
		if(!cols.containsAll(Arrays.asList("date_of_commencement", "date_of_begin_current_condition"))) notEcecuted.add("date of commencement <= date of begin current condition") ;
		if(!cols.containsAll(Arrays.asList("type_of_event", "status_end_current_condition"))) notEcecuted.add("type of event & status at end current condition") ;

		if(!cols.containsAll(Arrays.asList("date_of_event_incurred","cover_expiry_date"))) notEcecuted.add("date of event incurred & cover expiry date"); //sprint 3
		if(!cols.containsAll(Arrays.asList("date_of_end_current_condition","cover_expiry_date"))) notEcecuted.add("date of end current condition & cover expiry date"); //sprint 3
        if(!cols.containsAll(Arrays.asList("cover_expiry_date")) || (op_start == null || op_start.isEmpty()) ) notEcecuted.add("start of observation period <= cover expiry date"); //sprint 3
		if(!cols.containsAll(Arrays.asList("date_of_end_current_condition","cover_expiry_date")) || (op_end == null || op_end.isEmpty()) ) notEcecuted.add("date of end current condition <= end of observation period"); //sprint 3
		if(!cols.containsAll(Arrays.asList("date_of_begin_current_condition")) || (op_start == null || op_start.isEmpty()) ) notEcecuted.add("start of observation period <= date of begin current condition");//sprint3
		if(!cols.containsAll(Arrays.asList("life_id","policy_id","date_of_end_current_condition"))) notEcecuted.add("claims existence"); //sprint 3
		if(!cols.containsAll(Arrays.asList("date_of_event_notified","date_of_event_settled","date_of_event_paid"))) notEcecuted.add("date of event incurred & date of event notified & date of event settled & date of event paid"); //sprint 3
		if(!cols.containsAll(Arrays.asList("expenses_included","settlement_decision","event_amount_insurer","risk_amount_insurer","event_amount_reinsurer","risk_amount_reinsurer"))) notEcecuted.add("when death / withdrawal (lump sum), risk amount = event amount"); //sprint 3
		if(!cols.containsAll(Arrays.asList("life_id","policy_id","benefit_id","date_of_end_current_condition")) || (op_end == null || op_end.isEmpty()) ) notEcecuted.add("exposure end coherent with status"); //sprint 3



		if(!cols.containsAll(Arrays.asList("age_at_commencement","date_of_commencement","date_of_birth"))
				|| !cols_product.containsAll(Arrays.asList("age_definition"))
				) notEcecuted.add("date of commencement = age at commencement - date of birth") ;

		if(!cols.containsAll(Arrays.asList("cover_expiry_age","cover_expiry_date","date_of_birth"))
				|| !cols_product.containsAll(Arrays.asList("age_definition"))
				) notEcecuted.add("cover expiry date - date of birth <= cover expiry age") ; //sprint 3


		return notEcecuted;
	}
}
