package com.berexia.study.repositories;

import com.berexia.study.entities.RefTreatyEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface TreatyRepository extends CrudRepository<RefTreatyEntity, Integer>
{

    List<RefTreatyEntity> findByRtRcnId(int id);
}
