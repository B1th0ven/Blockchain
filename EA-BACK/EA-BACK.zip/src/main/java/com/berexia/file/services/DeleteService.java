package com.berexia.file.services;

import com.berexia.file.entities.file;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Service
public class DeleteService {

    public void delete(String filepath) throws IOException {
        Path path = Paths.get(filepath);
        System.out.println("File exits before deleting: " + Files.exists(path));
        Files.delete(path);
        System.out.println("File exits after deleting: " + Files.exists(path));
    }

}
