package com.berexia.ea.services;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.collections.ListUtils;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.berexia.ea.entities.ControlResults;
import com.berexia.ea.spark.CompColsCheck;
import com.berexia.ea.spark.FuncControls;
import com.berexia.ea.spark.TechControls;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class ControlsRestService {


	
	@RequestMapping(value = "/CompColsCheck", method = RequestMethod.POST)
	public List<List<String>> check(HttpEntity<String> req) throws JsonParseException, JsonMappingException, IOException{
		HashMap<String, Object> req_map = new ObjectMapper().readValue(req.getBody() , HashMap.class) ;
		String path = (String) req_map.get("path") ;
		String type = (String) req_map.get("type") ;
		CompColsCheck CCC = new CompColsCheck() ;
		if(type.equalsIgnoreCase("product")) return CCC.runProduct(path) ;
		return CCC.run(path, type) ;
	}
	
	
	
	
	@RequestMapping(value = "/TechControls", method = RequestMethod.POST)
	public List<ControlResults> techCtrl(HttpEntity<String> req) throws JsonParseException, JsonMappingException, IOException{
		HashMap<String, Object> req_map = new ObjectMapper().readValue(req.getBody() , HashMap.class) ;
		String path = (String) req_map.get("path_policy") ;
		String path_product = (String) req_map.get("path_product") ;
		String type = (String) req_map.get("type") ;
		ControlResults expoRes = TechControls.run(path, type) ;
		ControlResults prodRes = TechControls.runProduct(path_product) ;
		return 	Arrays.asList(expoRes , prodRes ) ;
	}





	@RequestMapping(value = "/FuncControls", method = RequestMethod.POST)
	public ControlResults funcCtrl(HttpEntity<String> req) throws JsonParseException, JsonMappingException, IOException{
		HashMap<String, Object> req_map = new ObjectMapper().readValue(req.getBody() , HashMap.class) ;
		String path = (String) req_map.get("path_policy") ;
		String path_product = (String) req_map.get("path_product") ;
		String type = (String) req_map.get("type") ;
		String op_start = (String) req_map.get("op_start");
		String op_end = (String) req_map.get("op_end");

		return FuncControls.run(path , path_product , type, op_start, op_end) ;
	}

	@RequestMapping(value = "/NotExecutedControls", method = RequestMethod.POST)
	public List<String> notExecutedTachControls(HttpEntity<String> req) throws JsonParseException, JsonMappingException, IOException{
		HashMap<String, Object> req_map = new ObjectMapper().readValue(req.getBody() , HashMap.class) ;
		String path = (String) req_map.get("path_policy") ;
		String path_product = (String) req_map.get("path_product") ;
		String type = (String) req_map.get("type") ;
		String op_start = (String) req_map.get("op_start");
		String op_end = (String) req_map.get("op_end");
		CompColsCheck CCC = new CompColsCheck() ;
		return CCC.notExecutedCtrl(path , path_product , type,op_start, op_end)  ;
	}
	
}
