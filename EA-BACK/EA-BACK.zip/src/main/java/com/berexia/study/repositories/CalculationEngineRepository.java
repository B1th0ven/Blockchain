package com.berexia.study.repositories;

import com.berexia.study.entities.RefCalculationEngineTypeEntity;
import org.springframework.data.repository.CrudRepository;

public interface CalculationEngineRepository extends CrudRepository<RefCalculationEngineTypeEntity, Integer>
{

}
