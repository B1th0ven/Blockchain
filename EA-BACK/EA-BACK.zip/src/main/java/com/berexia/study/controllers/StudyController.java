package com.berexia.study.controllers;

import com.berexia.study.entities.StudyEntity;
import com.berexia.study.services.StudyService;
import com.berexia.study.specifications.StudyEntityPage;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class StudyController {

    @Autowired
    private StudyService studyService;


    @RequestMapping("/studies")
    public StudyEntityPage getStudiesBySearch(
            @RequestParam("limit") int limit,
            @RequestParam("page") int page,
            @RequestParam("code") Optional<String> code,
            @RequestParam("country") Optional<String> country,
            @RequestParam("group") Optional<String> group,
            @RequestParam("treaty") Optional<String> treaty,
            @RequestParam("lob") Optional<String> lob,
            @RequestParam("client") Optional<String> client,
            @RequestParam("brand") Optional<String> brand,
            @RequestParam("status") Optional<String> status,
            @RequestParam("statusdate") Optional<String> statusdate,
            @RequestParam("sort") Optional<String> sort,
            @RequestParam("desc") Optional<Boolean> desc
    )
    {
        return studyService.searchByQuery(page,limit,code,country,group,client, brand,treaty, lob,status,statusdate,sort,desc);
    }

    @RequestMapping("/studies/")
    public Page<StudyEntity> getStudies(@RequestParam("limit") int limit,@RequestParam("page") int page)
    {
        Pageable p = new PageRequest(page, limit);
        return studyService.getPage(p);
    }

    @RequestMapping("/studies/{id}")
    public StudyEntity getStudy(@PathVariable("id") String id)
    {
        return studyService.getStudy( Integer.parseInt(id) );
    }

    @RequestMapping(method = RequestMethod.POST , value = "/studies" )
    public StudyEntity postStudy(@RequestBody StudyEntity st)
    {
        return studyService.postStudy(st);
    }

}
