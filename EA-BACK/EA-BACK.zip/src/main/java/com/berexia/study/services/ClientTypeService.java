package com.berexia.study.services;

import com.berexia.study.repositories.ClientTypeRepository;
import com.berexia.study.entities.RefRequesterEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ClientTypeService {

    @Autowired
    private ClientTypeRepository clientRepository;

    public List<RefRequesterEntity> getAllStudies()
    {
        List<RefRequesterEntity> list = new ArrayList<RefRequesterEntity>();

        for ( RefRequesterEntity st : clientRepository.findAll())
        {
            list.add(st);
        }
        return list;
    }

    public RefRequesterEntity getClient(int id )
    {
        return clientRepository.findOne(id);
    }

    public void postClient( RefRequesterEntity st )
    {
        clientRepository.save( st );
    }
}
