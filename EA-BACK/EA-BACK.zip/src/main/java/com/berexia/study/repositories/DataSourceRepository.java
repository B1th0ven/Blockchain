package com.berexia.study.repositories;

import com.berexia.study.entities.RefDataSourceEntity;
import org.springframework.data.repository.CrudRepository;

public interface DataSourceRepository extends CrudRepository<RefDataSourceEntity, Integer>
{

}
