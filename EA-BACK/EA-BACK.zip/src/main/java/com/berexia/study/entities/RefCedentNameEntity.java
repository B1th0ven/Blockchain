package com.berexia.study.entities;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "REF_CEDENT_NAME", schema = "dbo", catalog = "EXPAN")
public class RefCedentNameEntity {
    private int rcnId;
    private Integer rcnRpgId;
    private String rcnName;
    private String rcnDescription;
    private String rcnCommercialClientName;
    private Integer rcnRcId;
    private RefCountryEntity refCountryById;

    @Id
    @Column(name = "RCN_ID")
    public int getRcnId() {
        return rcnId;
    }

    public void setRcnId(int rcnId) {
        this.rcnId = rcnId;
    }

    @Basic
    @Column(name = "RCN_RPG_ID")
    public Integer getRcnRpgId() {
        return rcnRpgId;
    }

    public void setRcnRpgId(Integer rcnRpgId) {
        this.rcnRpgId = rcnRpgId;
    }

    @Basic
    @Column(name = "RCN_NAME")
    public String getRcnName() {
        return rcnName;
    }

    public void setRcnName(String rcnName) {
        this.rcnName = rcnName;
    }

    @Basic
    @Column(name = "RCN_DESCRIPTION")
    public String getRcnDescription() {
        return rcnDescription;
    }

    public void setRcnDescription(String rcnDescription) {
        this.rcnDescription = rcnDescription;
    }

    @Basic
    @Column(name = "RCN_COMMERCIAL_CLIENT_NAME")
    public String getRcnCommercialClientName() {
        return rcnCommercialClientName;
    }

    public void setRcnCommercialClientName(String rcnCommercialClientName) {
        this.rcnCommercialClientName = rcnCommercialClientName;
    }

    @Basic
    @Column(name = "RCN_RC_ID")
    public Integer getRcnRcId() {
        return rcnRcId;
    }

    public void setRcnRcId(Integer rcnRcId) {
        this.rcnRcId = rcnRcId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RefCedentNameEntity that = (RefCedentNameEntity) o;
        return rcnId == that.rcnId &&
                Objects.equals(rcnRpgId, that.rcnRpgId) &&
                Objects.equals(rcnName, that.rcnName) &&
                Objects.equals(rcnDescription, that.rcnDescription) &&
                Objects.equals(rcnCommercialClientName, that.rcnCommercialClientName) &&
                Objects.equals(rcnRcId, that.rcnRcId);
    }

    @Override
    public int hashCode() {

        return Objects.hash(rcnId, rcnRpgId, rcnName, rcnDescription, rcnCommercialClientName, rcnRcId);
    }

    @ManyToOne
    @JoinColumn( name = "RCN_RC_ID" , insertable = false , updatable = false )
    public RefCountryEntity getRefCountryById() {
        return refCountryById;
    }

    public void setRefCountryById(RefCountryEntity refCountryById) {
        this.refCountryById = refCountryById;
    }
}
