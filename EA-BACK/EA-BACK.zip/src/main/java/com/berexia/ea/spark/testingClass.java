package com.berexia.ea.spark;

import org.apache.hadoop.util.hash.Hash;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.util.LongAccumulator;
import org.codehaus.jettison.json.JSONObject;
import scala.Serializable;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class testingClass implements Serializable {
    private static final long serialVersionUID = 1L;





    public HashMap<String,Long> run(){
        JavaSparkContext sc = Connection.getContext();
        LongAccumulator ac = sc.sc().longAccumulator();
        JavaRDD<String> data = sc.textFile("C:\\Users\\Wajdi\\Desktop\\back\\files\\input.txt");
       /* JavaPairRDD<String, Integer> counts = data
                .flatMap(s -> Arrays.asList(s.split(" ")).iterator())
                .mapToPair(word -> new Tuple2<>(word, 1))
                .reduceByKey((a, b) -> a + b);
        /*String header = data.first();
        List<String> cols = new ArrayList<String>(Arrays.asList(header.toLowerCase().trim().split(";",-1)));
        ArrayList list = new ArrayList();*/

      /*  List<Tuple2<String,Integer>> res = counts.collect();
        for (Tuple2<String,Integer> item : res) {
            HashMap<String,Integer> hmap = new HashMap<String,Integer>();
            hmap.put(item._1,item._2);
            list.add(hmap);
        }*/

      data.foreach(new VoidFunction<String>() {
          /**
           *
           */
          private static final long serialVersionUID = 1L;

          @Override
          public void call(String s) throws Exception {
              if(s.contains("wajdi"))
                  ac.add(1);
          }
      });
        HashMap<String,Long> hmap = new HashMap<>();
        hmap.put("Wajdi",ac.value());
        return hmap;
    }


}
