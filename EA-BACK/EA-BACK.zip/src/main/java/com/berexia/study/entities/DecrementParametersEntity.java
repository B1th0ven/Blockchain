package com.berexia.study.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.sql.Date;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "DECREMENT_PARAMETERS", schema = "dbo", catalog = "EXPAN")
public class DecrementParametersEntity {
    private int dpId;
    private String dpDecrement;
    private Boolean dpSlicingDimensionAge;
    private Boolean dpSlicingDimensionDuration;
    private Boolean dpSlicingDimensionCalenderYear;
    private String dpLeadingSlicingDimension;
    private String dpSlicingGranularity;
    private String dpMonthlyDuration;
    private String dpMonthlyDurationBy;
    private Date dpStudyPeriodStartDate;
    private Date dpStudyPeriodEndDate;
    private Boolean dpStudyPeriodTruncated;
    private Boolean dpIncludePartial;
    //private Integer dpRunId;
    private Collection<DecrementExpectedTableEntity> decrementExpectedTablesByDpId;
    private RunEntity runByDpRunId;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DP_ID")
    public int getDpId() {
        return dpId;
    }

    public void setDpId(int dpId) {
        this.dpId = dpId;
    }

    @Basic
    @Column(name = "DP_DECREMENT")
    public String getDpDecrement() {
        return dpDecrement;
    }

    public void setDpDecrement(String dpDecrement) {
        this.dpDecrement = dpDecrement;
    }

    @Basic
    @Column(name = "DP_SLICING_DIMENSION_AGE")
    public Boolean getDpSlicingDimensionAge() {
        return dpSlicingDimensionAge;
    }

    public void setDpSlicingDimensionAge(Boolean dpSlicingDimensionAge) {
        this.dpSlicingDimensionAge = dpSlicingDimensionAge;
    }

    @Basic
    @Column(name = "DP_SLICING_DIMENSION_DURATION")
    public Boolean getDpSlicingDimensionDuration() {
        return dpSlicingDimensionDuration;
    }

    public void setDpSlicingDimensionDuration(Boolean dpSlicingDimensionDuration) {
        this.dpSlicingDimensionDuration = dpSlicingDimensionDuration;
    }

    @Basic
    @Column(name = "DP_SLICING_DIM_CALENDER_YEAR")
    public Boolean getDpSlicingDimensionCalenderYear() {
        return dpSlicingDimensionCalenderYear;
    }

    public void setDpSlicingDimensionCalenderYear(Boolean dpSlicingDimensionCalenderYear) {
        this.dpSlicingDimensionCalenderYear = dpSlicingDimensionCalenderYear;
    }

    @Basic
    @Column(name = "DP_LEADING_SLICING_DIMENSION")
    public String getDpLeadingSlicingDimension() {
        return dpLeadingSlicingDimension;
    }

    public void setDpLeadingSlicingDimension(String dpLeadingSlicingDimension) {
        this.dpLeadingSlicingDimension = dpLeadingSlicingDimension;
    }

    @Basic
    @Column(name = "DP_SLICING_GRANULARITY")
    public String getDpSlicingGranularity() {
        return dpSlicingGranularity;
    }

    public void setDpSlicingGranularity(String dpSlicingGranularity) {
        this.dpSlicingGranularity = dpSlicingGranularity;
    }

    @Basic
    @Column(name = "DP_MONTHLY_DURATION")
    public String getDpMonthlyDuration() {
        return dpMonthlyDuration;
    }

    public void setDpMonthlyDuration(String dpMonthlyDuration) {
        this.dpMonthlyDuration = dpMonthlyDuration;
    }

    @Basic
    @Column(name = "DP_MONTHLY_DURATION_BY")
    public String getDpMonthlyDurationBy() {
        return dpMonthlyDurationBy;
    }

    public void setDpMonthlyDurationBy(String dpMonthlyDurationBy) {
        this.dpMonthlyDurationBy = dpMonthlyDurationBy;
    }

    @Basic
    @Column(name = "DP_STUDY_PERIOD_START_DATE")
    public Date getDpStudyPeriodStartDate() {
        return dpStudyPeriodStartDate;
    }

    public void setDpStudyPeriodStartDate(Date dpStudyPeriodStartDate) {
        this.dpStudyPeriodStartDate = dpStudyPeriodStartDate;
    }

    @Basic
    @Column(name = "DP_STUDY_PERIOD_END_DATE")
    public Date getDpStudyPeriodEndDate() {
        return dpStudyPeriodEndDate;
    }

    public void setDpStudyPeriodEndDate(Date dpStudyPeriodEndDate) {
        this.dpStudyPeriodEndDate = dpStudyPeriodEndDate;
    }

    @Basic
    @Column(name = "DP_STUDY_PERIOD_TRUNCATED")
    public Boolean getDpStudyPeriodTruncated() {
        return dpStudyPeriodTruncated;
    }

    public void setDpStudyPeriodTruncated(Boolean dpStudyPeriodTruncated) {
        this.dpStudyPeriodTruncated = dpStudyPeriodTruncated;
    }

    @Basic
    @Column(name = "DP_INCLUDE_PARTIAL")
    public Boolean getDpIncludePartial() {
        return dpIncludePartial;
    }

    public void setDpIncludePartial(Boolean dpIncludePartial) {
        this.dpIncludePartial = dpIncludePartial;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DecrementParametersEntity that = (DecrementParametersEntity) o;
        return dpId == that.dpId &&
                Objects.equals(dpDecrement, that.dpDecrement) &&
                Objects.equals(dpSlicingDimensionAge, that.dpSlicingDimensionAge) &&
                Objects.equals(dpSlicingDimensionDuration, that.dpSlicingDimensionDuration) &&
                Objects.equals(dpSlicingDimensionCalenderYear, that.dpSlicingDimensionCalenderYear) &&
                Objects.equals(dpLeadingSlicingDimension, that.dpLeadingSlicingDimension) &&
                Objects.equals(dpSlicingGranularity, that.dpSlicingGranularity) &&
                Objects.equals(dpMonthlyDuration, that.dpMonthlyDuration) &&
                Objects.equals(dpMonthlyDurationBy, that.dpMonthlyDurationBy) &&
                Objects.equals(dpStudyPeriodStartDate, that.dpStudyPeriodStartDate) &&
                Objects.equals(dpStudyPeriodEndDate, that.dpStudyPeriodEndDate) &&
                Objects.equals(dpStudyPeriodTruncated, that.dpStudyPeriodTruncated) &&
                Objects.equals(dpIncludePartial, that.dpIncludePartial);
    }

    @Override
    public int hashCode() {

        return Objects.hash(dpId, dpDecrement, dpSlicingDimensionAge, dpSlicingDimensionDuration, dpSlicingDimensionCalenderYear, dpLeadingSlicingDimension, dpSlicingGranularity, dpMonthlyDuration, dpMonthlyDurationBy, dpStudyPeriodStartDate, dpStudyPeriodEndDate, dpStudyPeriodTruncated, dpIncludePartial);
    }
    /*
    @Basic
    @Column(name = "DP_RUN_ID")
    public Integer getDpRunId() {
        return dpRunId;
    }

    public void setDpRunId(Integer dpRunId) {
        this.dpRunId = dpRunId;
    }
    */

    @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true)
    @JoinColumn(name = "RET_DP_ID", referencedColumnName = "DP_ID")
    @JsonManagedReference
    public Collection<DecrementExpectedTableEntity> getDecrementExpectedTablesByDpId() {
        return decrementExpectedTablesByDpId;
    }

    public void setDecrementExpectedTablesByDpId(Collection<DecrementExpectedTableEntity> decrementExpectedTablesByDpId) {
        this.decrementExpectedTablesByDpId = decrementExpectedTablesByDpId;
    }

    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "DP_RUN_ID", referencedColumnName = "RUN_ID")
    public RunEntity getRunByDpRunId() {
        return runByDpRunId;
    }

    public void setRunByDpRunId(RunEntity runByDpRunId) {
        this.runByDpRunId = runByDpRunId;
}

}
