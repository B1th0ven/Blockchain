package com.berexia.study.services;

import com.berexia.study.entities.RefExpectedTableEntity;
import com.berexia.study.entities.RefLobEntity;
import com.berexia.study.repositories.BusinessRepository;
import com.berexia.study.repositories.CountryRepository;
import com.berexia.study.repositories.ExpectedTableRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ExpectedTableService {

    @Autowired
    private ExpectedTableRepository repository;
    @Autowired
    private CountryRepository countryRepository;

    public List<RefExpectedTableEntity> getAll()
    {
        List<RefExpectedTableEntity> list = new ArrayList<RefExpectedTableEntity>();

        for ( RefExpectedTableEntity t : repository.findAll())
        {
            list.add(t);
        }
        return list;
    }

    public RefExpectedTableEntity save(RefExpectedTableEntity t)
    {
        String tCodePrefix = getPrefixString(t);
        List<RefExpectedTableEntity> latestTable = repository.getLatestVersion(tCodePrefix);
        int v = 1;

        if ( t.getRetVersion() == 0 || t.getRetCode() == null )
        {
            if (latestTable.size()>=1)
            {
                latestTable.forEach(pt-> pt.setRetLatestVersion(false));
                v = latestTable.get(0).getRetVersion()+1;
                repository.save(latestTable);
            }
            t.setRetCode(tCodePrefix+"_"+v);
            t.setRetVersion(v);
            t.setRetLatestVersion(true);
        }

        return this.repository.save(t);
    }

    public int getLatestVersion(RefExpectedTableEntity t)
    {
        String tCodePrefix = getPrefixString(t);
        List<RefExpectedTableEntity> latestTable = repository.getLatestVersion(tCodePrefix);

        return  (latestTable.size()>=1)?latestTable.get(0).getRetVersion():0;
    }

    private String getPrefixString(RefExpectedTableEntity t) {
        String cCode = countryRepository.findOne(t.getRetRcId()).getRcCode().trim();

        String tCodePrefix = cCode + "_" +  t.getRetDecrement() +  "_" + t.getRetName() + "_" +  t.getRetPublicationYear() ;
        tCodePrefix = tCodePrefix.toUpperCase();
        return tCodePrefix;
    }

}
